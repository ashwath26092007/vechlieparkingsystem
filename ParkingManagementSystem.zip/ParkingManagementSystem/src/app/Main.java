package app;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;
import dao.AdminDAO;
import dao.ParkingLotDAO;
import dao.ParkingSlotDAO;
import dao.ParkingRecordDAO;
import dao.PaymentDAO;
import dao.VehicleDAO;
import model.ParkingLot;
import model.ParkingSlot;
import model.ParkingRecord;
import model.Payment;
import model.Vehicle;
import util.DatabaseSetup;
import util.FeeCalculator;

// Main console application for Parking Management System
public class Main {

    static Scanner scanner = new Scanner(System.in);
    static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    // DAO instances
    static AdminDAO adminDAO = new AdminDAO();
    static ParkingLotDAO parkingLotDAO = new ParkingLotDAO();
    static ParkingSlotDAO parkingSlotDAO = new ParkingSlotDAO();
    static VehicleDAO vehicleDAO = new VehicleDAO();
    static ParkingRecordDAO parkingRecordDAO = new ParkingRecordDAO();
    static PaymentDAO paymentDAO = new PaymentDAO();

    public static void main(String[] args) {
        System.out.println("=================================================");
        System.out.println("      PARKING MANAGEMENT SYSTEM (CORE JAVA)      ");
        System.out.println("=================================================");

        // Step 1: Initialize database, tables, and demo seed data
        if (!DatabaseSetup.init()) {
            System.out.println("Fatal: Could not initialize database. Application shutting down.");
            return;
        }

        // Step 2: Administrator login (maximum 3 attempts)
        if (!adminLogin()) {
            System.out.println("\nMaximum login attempts exceeded. Access denied. Exiting application.");
            return;
        }

        // Step 3: Main Menu loop
        while (true) {
            printMainMenu();
            int choice = readInt("Enter choice (1-11): ");

            switch (choice) {
                case 1:
                    manageParkingLotsMenu();
                    break;
                case 2:
                    manageParkingSlotsMenu();
                    break;
                case 3:
                    manageVehiclesMenu();
                    break;
                case 4:
                    vehicleEntryWorkflow();
                    break;
                case 5:
                    vehicleExitWorkflow();
                    break;
                case 6:
                    viewParkingRecordsMenu();
                    break;
                case 7:
                    managePaymentsMenu();
                    break;
                case 8:
                    searchVehicleQuick();
                    break;
                case 9:
                    reportsAndStatisticsMenu();
                    break;
                case 10:
                    parkingAvailabilityMenu();
                    break;
                case 11:
                    System.out.println("\nThank you for using Parking Management System. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid selection. Please enter a number between 1 and 11.");
            }
        }
    }

    // ==========================================
    // 1. ADMIN LOGIN
    // ==========================================
    private static boolean adminLogin() {
        System.out.println("\n----------------- ADMIN LOGIN -----------------");
        System.out.println("(Demonstration Credentials: Username = admin | Password = admin123)");

        for (int attempt = 1; attempt <= 3; attempt++) {
            System.out.println("\nAttempt " + attempt + " of 3:");
            String username = readLine("Enter Username: ");
            String password = readLine("Enter Password: ");

            if (adminDAO.login(username, password)) {
                System.out.println("\n>>> Login successful! Welcome, " + username + ".");
                return true;
            } else {
                System.out.println("Invalid username or password.");
                if (attempt < 3) {
                    System.out.println("Remaining attempts: " + (3 - attempt));
                }
            }
        }
        return false;
    }

    // ==========================================
    // MAIN MENU DISPLAY
    // ==========================================
    private static void printMainMenu() {
        System.out.println("\n========== PARKING MANAGEMENT SYSTEM ==========");
        System.out.println("1.  Manage Parking Lots");
        System.out.println("2.  Manage Parking Slots");
        System.out.println("3.  Manage Vehicles");
        System.out.println("4.  Vehicle Entry");
        System.out.println("5.  Vehicle Exit");
        System.out.println("6.  View Parking Records");
        System.out.println("7.  Manage Payments");
        System.out.println("8.  Search Vehicle");
        System.out.println("9.  Reports and Statistics");
        System.out.println("10. Parking Availability");
        System.out.println("11. Exit");
        System.out.println("===============================================");
    }

    // ==========================================
    // 5. PARKING LOT MANAGEMENT
    // ==========================================
    private static void manageParkingLotsMenu() {
        while (true) {
            System.out.println("\n--- MANAGE PARKING LOTS ---");
            System.out.println("1. Add a parking lot");
            System.out.println("2. View all parking lots");
            System.out.println("3. Search a parking lot by ID");
            System.out.println("4. Search parking lots by location");
            System.out.println("5. Update parking lot details");
            System.out.println("6. Activate or deactivate a parking lot");
            System.out.println("7. Delete a parking lot");
            System.out.println("0. Back to Main Menu");
            int choice = readInt("Enter choice: ");

            switch (choice) {
                case 1:
                    String name = readNonEmptyLine("Enter lot name: ");
                    String location = readNonEmptyLine("Enter location (e.g. Downtown, Terminal 1): ");
                    String address = readLine("Enter address: ");
                    int capacity = readPositiveInt("Enter total capacity: ");
                    String openTime = readLineWithDefault("Enter opening time [06:00 AM]: ", "06:00 AM");
                    String closeTime = readLineWithDefault("Enter closing time [11:00 PM]: ", "11:00 PM");
                    ParkingLot lot = new ParkingLot(name, location, address, capacity, openTime, closeTime, "Active");
                    if (parkingLotDAO.addParkingLot(lot)) {
                        System.out.println(">>> Parking lot added successfully!");
                    }
                    break;
                case 2:
                    parkingLotDAO.viewAllLots();
                    break;
                case 3:
                    int id = readInt("Enter Parking Lot ID: ");
                    parkingLotDAO.searchById(id);
                    break;
                case 4:
                    String loc = readNonEmptyLine("Enter location keyword: ");
                    parkingLotDAO.searchByLocation(loc);
                    break;
                case 5:
                    int updateId = readInt("Enter Parking Lot ID to update: ");
                    ParkingLot existing = parkingLotDAO.getLotById(updateId);
                    if (existing == null) {
                        System.out.println("Parking lot not found.");
                        break;
                    }
                    System.out.println("Leave blank to keep existing value.");
                    String newName = readLine("New Name [" + existing.getName() + "]: ");
                    if (!newName.isEmpty()) existing.setName(newName);

                    String newLoc = readLine("New Location [" + existing.getLocation() + "]: ");
                    if (!newLoc.isEmpty()) existing.setLocation(newLoc);

                    String newAddr = readLine("New Address [" + existing.getAddress() + "]: ");
                    if (!newAddr.isEmpty()) existing.setAddress(newAddr);

                    String capStr = readLine("New Capacity [" + existing.getTotalCapacity() + "]: ");
                    if (!capStr.isEmpty()) {
                        try {
                            int capVal = Integer.parseInt(capStr);
                            if (capVal > 0) existing.setTotalCapacity(capVal);
                        } catch (NumberFormatException ignored) {}
                    }

                    String newOpen = readLine("New Opening Time [" + existing.getOpeningTime() + "]: ");
                    if (!newOpen.isEmpty()) existing.setOpeningTime(newOpen);

                    String newClose = readLine("New Closing Time [" + existing.getClosingTime() + "]: ");
                    if (!newClose.isEmpty()) existing.setClosingTime(newClose);

                    if (parkingLotDAO.updateLot(existing)) {
                        System.out.println(">>> Parking lot updated successfully!");
                    }
                    break;
                case 6:
                    int statusLotId = readInt("Enter Parking Lot ID: ");
                    ParkingLot pLot = parkingLotDAO.getLotById(statusLotId);
                    if (pLot == null) {
                        System.out.println("Parking lot not found.");
                        break;
                    }
                    System.out.println("Current status: " + pLot.getStatus());
                    System.out.println("1. Set Active");
                    System.out.println("2. Set Inactive");
                    int sChoice = readInt("Choose status: ");
                    String newStatus = (sChoice == 2) ? "Inactive" : "Active";
                    if (parkingLotDAO.setLotStatus(statusLotId, newStatus)) {
                        System.out.println(">>> Parking lot status set to " + newStatus + ".");
                    }
                    break;
                case 7:
                    int delId = readInt("Enter Parking Lot ID to delete: ");
                    String confirm = readLine("Are you sure you want to delete Lot #" + delId + "? (y/n): ");
                    if ("y".equalsIgnoreCase(confirm)) {
                        if (parkingLotDAO.deleteLot(delId)) {
                            System.out.println(">>> Parking lot deleted successfully.");
                        }
                    } else {
                        System.out.println("Deletion cancelled.");
                    }
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    // ==========================================
    // 6. PARKING SLOT MANAGEMENT
    // ==========================================
    private static void manageParkingSlotsMenu() {
        while (true) {
            System.out.println("\n--- MANAGE PARKING SLOTS ---");
            System.out.println("1. Add a parking slot manually");
            System.out.println("2. Generate parking slots automatically for a lot");
            System.out.println("3. View all slots");
            System.out.println("4. View slots by parking lot");
            System.out.println("5. Search a slot by ID or slot number");
            System.out.println("6. Update slot details");
            System.out.println("7. Change slot status (Block / Unblock)");
            System.out.println("8. View slots by status (Available / Occupied / Blocked)");
            System.out.println("9. Delete a parking slot");
            System.out.println("0. Back to Main Menu");
            int choice = readInt("Enter choice: ");

            switch (choice) {
                case 1:
                    int lotId = readInt("Enter Parking Lot ID: ");
                    if (parkingLotDAO.getLotById(lotId) == null) {
                        System.out.println("Error: Parking lot does not exist.");
                        break;
                    }
                    String slotNum = readNonEmptyLine("Enter Slot Number (e.g. S001, B10): ");
                    String slotType = selectVehicleType();
                    ParkingSlot newSlot = new ParkingSlot(lotId, slotNum, slotType, "Available");
                    if (parkingSlotDAO.addSlot(newSlot)) {
                        System.out.println(">>> Parking slot created successfully!");
                    }
                    break;
                case 2:
                    int genLotId = readInt("Enter Parking Lot ID: ");
                    ParkingLot targetLot = parkingLotDAO.getLotById(genLotId);
                    if (targetLot == null) {
                        System.out.println("Error: Parking lot does not exist.");
                        break;
                    }
                    String prefix = readLineWithDefault("Enter slot prefix [S]: ", "S");
                    int count = readPositiveInt("How many slots to generate?: ");
                    String genType = selectVehicleType();
                    int created = parkingSlotDAO.generateSlots(genLotId, prefix, count, genType);
                    System.out.println(">>> Successfully generated " + created + " slots in Lot '" + targetLot.getName() + "'.");
                    break;
                case 3:
                    parkingSlotDAO.viewAllSlots();
                    break;
                case 4:
                    int vLotId = readInt("Enter Parking Lot ID: ");
                    parkingSlotDAO.viewSlotsByLot(vLotId);
                    break;
                case 5:
                    String query = readNonEmptyLine("Enter Slot ID or Slot Number: ");
                    parkingSlotDAO.searchSlot(query);
                    break;
                case 6:
                    int sId = readInt("Enter Slot ID to update: ");
                    ParkingSlot sObj = parkingSlotDAO.getSlotById(sId);
                    if (sObj == null) {
                        System.out.println("Slot not found.");
                        break;
                    }
                    String newSlotNum = readLine("New Slot Number [" + sObj.getSlotNumber() + "]: ");
                    if (!newSlotNum.isEmpty()) sObj.setSlotNumber(newSlotNum);

                    System.out.println("Current Type: " + sObj.getSlotType());
                    System.out.print("Change Type? (y/n): ");
                    if ("y".equalsIgnoreCase(scanner.nextLine().trim())) {
                        sObj.setSlotType(selectVehicleType());
                    }

                    if (parkingSlotDAO.updateSlot(sObj)) {
                        System.out.println(">>> Slot updated successfully!");
                    }
                    break;
                case 7:
                    int blockSlotId = readInt("Enter Slot ID: ");
                    ParkingSlot currentSlot = parkingSlotDAO.getSlotById(blockSlotId);
                    if (currentSlot == null) {
                        System.out.println("Slot not found.");
                        break;
                    }
                    System.out.println("Current Slot Status: " + currentSlot.getStatus());
                    System.out.println("1. Available (Unblock)");
                    System.out.println("2. Blocked (Maintenance / Reserved)");
                    int bChoice = readInt("Select new status: ");
                    String changedStatus = (bChoice == 2) ? "Blocked" : "Available";
                    if (parkingSlotDAO.changeSlotStatus(blockSlotId, changedStatus)) {
                        System.out.println(">>> Slot status updated to " + changedStatus + ".");
                    }
                    break;
                case 8:
                    System.out.println("1. Available");
                    System.out.println("2. Occupied");
                    System.out.println("3. Blocked");
                    int statChoice = readInt("Choose status to filter: ");
                    String filterStat = "Available";
                    if (statChoice == 2) filterStat = "Occupied";
                    else if (statChoice == 3) filterStat = "Blocked";
                    parkingSlotDAO.displaySlotsByStatus(filterStat);
                    break;
                case 9:
                    int delSlotId = readInt("Enter Slot ID to delete: ");
                    if (parkingSlotDAO.deleteSlot(delSlotId)) {
                        System.out.println(">>> Slot deleted successfully.");
                    }
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    // ==========================================
    // 7. VEHICLE MANAGEMENT
    // ==========================================
    private static void manageVehiclesMenu() {
        while (true) {
            System.out.println("\n--- MANAGE VEHICLES ---");
            System.out.println("1. Register a vehicle");
            System.out.println("2. View all registered vehicles");
            System.out.println("3. Search vehicle by registration number");
            System.out.println("4. Search vehicles by owner name");
            System.out.println("5. Search vehicles by type");
            System.out.println("6. Update vehicle details");
            System.out.println("7. View a vehicle's parking history");
            System.out.println("0. Back to Main Menu");
            int choice = readInt("Enter choice: ");

            switch (choice) {
                case 1:
                    registerVehiclePrompt();
                    break;
                case 2:
                    vehicleDAO.viewAllVehicles();
                    break;
                case 3:
                    String reg = readNonEmptyLine("Enter registration number: ");
                    vehicleDAO.searchByRegNumber(reg);
                    break;
                case 4:
                    String owner = readNonEmptyLine("Enter owner name: ");
                    vehicleDAO.searchByOwnerName(owner);
                    break;
                case 5:
                    String type = selectVehicleType();
                    vehicleDAO.searchByType(type);
                    break;
                case 6:
                    String regToUpdate = readNonEmptyLine("Enter registration number of vehicle to update: ");
                    Vehicle v = vehicleDAO.getVehicleByRegNumber(regToUpdate);
                    if (v == null) {
                        System.out.println("Vehicle not found.");
                        break;
                    }
                    String newOwner = readLine("New Owner Name [" + v.getOwnerName() + "]: ");
                    if (!newOwner.isEmpty()) v.setOwnerName(newOwner);

                    String newPhone = readLine("New Owner Phone [" + v.getOwnerPhone() + "]: ");
                    if (!newPhone.isEmpty()) v.setOwnerPhone(newPhone);

                    String newModel = readLine("New Model [" + v.getModel() + "]: ");
                    if (!newModel.isEmpty()) v.setModel(newModel);

                    System.out.print("Update Vehicle Type? (y/n): ");
                    if ("y".equalsIgnoreCase(scanner.nextLine().trim())) {
                        v.setVehicleType(selectVehicleType());
                    }

                    if (vehicleDAO.updateVehicle(v)) {
                        System.out.println(">>> Vehicle details updated successfully!");
                    }
                    break;
                case 7:
                    String histReg = readNonEmptyLine("Enter vehicle registration number: ");
                    vehicleDAO.viewParkingHistory(histReg);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static Vehicle registerVehiclePrompt() {
        String reg = readNonEmptyLine("Enter registration number (e.g. KA-01-AB-1234): ").toUpperCase();
        if (vehicleDAO.getVehicleByRegNumber(reg) != null) {
            System.out.println("Vehicle is already registered.");
            return vehicleDAO.getVehicleByRegNumber(reg);
        }
        String type = selectVehicleType();
        String owner = readNonEmptyLine("Enter owner name: ");
        String phone = readPhone("Enter owner phone number: ");
        String model = readLine("Enter vehicle model (e.g. Honda City): ");
        Vehicle newVehicle = new Vehicle(reg, type, owner, phone, model, LocalDateTime.now());
        if (vehicleDAO.registerVehicle(newVehicle)) {
            System.out.println(">>> Vehicle registered successfully!");
            return vehicleDAO.getVehicleByRegNumber(reg);
        }
        return null;
    }

    // ==========================================
    // 8. VEHICLE ENTRY MANAGEMENT
    // ==========================================
    private static void vehicleEntryWorkflow() {
        System.out.println("\n================= VEHICLE ENTRY PROCESS =================");
        String regNumber = readNonEmptyLine("Enter vehicle registration number: ").toUpperCase();

        // 1. Check if registered
        Vehicle vehicle = vehicleDAO.getVehicleByRegNumber(regNumber);
        if (vehicle == null) {
            System.out.println("Vehicle '" + regNumber + "' is not registered in the system.");
            String regChoice = readLine("Would you like to register this vehicle now? (y/n): ");
            if ("y".equalsIgnoreCase(regChoice)) {
                vehicle = registerVehiclePrompt();
                if (vehicle == null) {
                    System.out.println("Registration failed. Entry aborted.");
                    return;
                }
            } else {
                System.out.println("Vehicle must be registered to enter. Entry aborted.");
                return;
            }
        }

        // 2. Check whether vehicle already has an active session
        ParkingRecord activeSession = parkingRecordDAO.findActiveRecord(regNumber);
        if (activeSession != null) {
            System.out.println("\n[ERROR] Entry Rejected!");
            System.out.println("Vehicle " + regNumber + " already has an ACTIVE parking session (Record #" + activeSession.getRecordId() + ").");
            System.out.println("Currently parked at Lot: " + activeSession.getLotName() + ", Slot: " + activeSession.getSlotNumber());
            return;
        }

        // 3. Display active parking lots
        System.out.println("\nAvailable Active Parking Lots:");
        List<ParkingLot> activeLots = parkingLotDAO.getAllActiveLots();
        if (activeLots.isEmpty()) {
            System.out.println("No active parking lots found. Please activate or create a parking lot first.");
            return;
        }

        System.out.printf("%-6s | %-22s | %-16s | %-10s%n", "Lot ID", "Name", "Location", "Capacity");
        System.out.println("------------------------------------------------------------------");
        for (ParkingLot lot : activeLots) {
            System.out.printf("%-6d | %-22s | %-16s | %-10d%n",
                    lot.getLotId(), lot.getName(), lot.getLocation(), lot.getTotalCapacity());
        }

        int lotId = readInt("\nSelect Parking Lot ID: ");
        ParkingLot chosenLot = null;
        for (ParkingLot lot : activeLots) {
            if (lot.getLotId() == lotId) {
                chosenLot = lot;
                break;
            }
        }
        if (chosenLot == null) {
            System.out.println("Invalid parking lot ID. Entry cancelled.");
            return;
        }

        // 4. Display available slots compatible with vehicle type
        List<ParkingSlot> availableSlots = parkingSlotDAO.getAvailableSlots(lotId, vehicle.getVehicleType());
        if (availableSlots.isEmpty()) {
            System.out.println("\n[ERROR] No available slots of type '" + vehicle.getVehicleType()
                    + "' in " + chosenLot.getName() + ".");
            System.out.println("Entry rejected. Please select another parking lot.");
            return;
        }

        System.out.println("\nAvailable compatible slots for " + vehicle.getVehicleType() + ":");
        System.out.printf("%-8s | %-12s | %-16s%n", "Slot ID", "Slot Number", "Slot Type");
        System.out.println("-------------------------------------");
        for (ParkingSlot s : availableSlots) {
            System.out.printf("%-8d | %-12s | %-16s%n", s.getSlotId(), s.getSlotNumber(), s.getSlotType());
        }

        int slotId = readInt("\nSelect Slot ID: ");
        ParkingSlot chosenSlot = null;
        for (ParkingSlot s : availableSlots) {
            if (s.getSlotId() == slotId) {
                chosenSlot = s;
                break;
            }
        }
        if (chosenSlot == null) {
            System.out.println("Invalid slot selection. Entry aborted.");
            return;
        }

        // 5. Execute entry in transaction
        int recordId = parkingRecordDAO.recordVehicleEntry(vehicle.getVehicleId(), chosenLot.getLotId(), chosenSlot.getSlotId());
        if (recordId > 0) {
            LocalDateTime entryTime = LocalDateTime.now();
            System.out.println("\n=======================================================");
            System.out.println("              PARKING ENTRY CONFIRMATION               ");
            System.out.println("=======================================================");
            System.out.println(" Parking Record ID : " + recordId);
            System.out.println(" Vehicle Number    : " + vehicle.getRegistrationNumber());
            System.out.println(" Vehicle Type      : " + vehicle.getVehicleType());
            System.out.println(" Owner Name        : " + vehicle.getOwnerName());
            System.out.println(" Parking Lot       : " + chosenLot.getName());
            System.out.println(" Slot Number       : " + chosenSlot.getSlotNumber());
            System.out.println(" Entry Date & Time : " + entryTime.format(dtf));
            System.out.println(" Status            : Active (Parked)");
            System.out.println("=======================================================");
            System.out.println(">>> Vehicle checked-in successfully! Slot marked Occupied.");
        } else {
            System.out.println("Vehicle entry failed due to database or concurrency constraint.");
        }
    }

    // ==========================================
    // 9. VEHICLE EXIT MANAGEMENT
    // ==========================================
    private static void vehicleExitWorkflow() {
        System.out.println("\n================= VEHICLE EXIT PROCESS =================");
        String input = readNonEmptyLine("Enter Vehicle Registration Number OR Parking Record ID: ");

        // 1. Locate active session
        ParkingRecord record = parkingRecordDAO.findActiveRecord(input);
        if (record == null) {
            System.out.println("No ACTIVE parking record found for '" + input + "'.");
            System.out.println("(Vehicle may not be parked currently or session is already completed).");
            return;
        }

        // 2. Calculate duration and fee
        LocalDateTime entryTime = record.getEntryTime();
        LocalDateTime exitTime = LocalDateTime.now();

        Duration duration = Duration.between(entryTime, exitTime);
        long totalMinutes = duration.toMinutes();
        if (totalMinutes < 0) totalMinutes = 0;

        long hoursPart = totalMinutes / 60;
        long minutesPart = totalMinutes % 60;
        int billedHours = FeeCalculator.calculateBilledHours(totalMinutes);
        double fee = FeeCalculator.calculateFee(record.getVehicleType(), totalMinutes);

        // 3. Display Parking Summary
        System.out.println("\n=======================================================");
        System.out.println("                  PARKING EXIT SUMMARY                 ");
        System.out.println("=======================================================");
        System.out.println(" Parking Record ID : " + record.getRecordId());
        System.out.println(" Vehicle Reg Number: " + record.getRegistrationNumber());
        System.out.println(" Vehicle Type      : " + record.getVehicleType());
        System.out.println(" Parking Lot       : " + record.getLotName());
        System.out.println(" Slot Number       : " + record.getSlotNumber());
        System.out.println(" Entry Time        : " + entryTime.format(dtf));
        System.out.println(" Exit Time         : " + exitTime.format(dtf));
        System.out.printf(" Actual Duration   : %d hr %d min%n", hoursPart, minutesPart);
        System.out.println(" Billed Duration   : " + billedHours + " hour(s) (partial hours rounded up)");
        System.out.printf(" Parking Fee       : Rs. %.2f%n", fee);
        System.out.println(" Payment Status    : Pending");
        System.out.println("=======================================================");

        // 4. Confirm exit
        String confirm = readLine("Confirm vehicle checkout and release parking slot? (y/n): ");
        if (!"y".equalsIgnoreCase(confirm)) {
            System.out.println("Exit cancelled. Vehicle remains parked.");
            return;
        }

        // 5. Complete session in transaction
        boolean exitSuccess = parkingRecordDAO.recordVehicleExit(record.getRecordId(), record.getSlotId(), exitTime, billedHours, fee);
        if (exitSuccess) {
            System.out.println("\n>>> Vehicle exit recorded successfully! Slot '" + record.getSlotNumber() + "' is now AVAILABLE.");

            // Offer to proceed to payment recording
            String payNow = readLine("Proceed to record payment now? (y/n): ");
            if ("y".equalsIgnoreCase(payNow)) {
                recordPaymentPrompt(record.getRecordId(), fee, record.getRegistrationNumber());
            } else {
                System.out.println("Payment deferred. You can record payment later in 'Manage Payments' (Option 7).");
            }
        } else {
            System.out.println("Error processing vehicle exit. Transaction rolled back.");
        }
    }

    // ==========================================
    // 11. PAYMENT MANAGEMENT
    // ==========================================
    private static void managePaymentsMenu() {
        while (true) {
            System.out.println("\n--- MANAGE PAYMENTS ---");
            System.out.println("1. Record a parking payment");
            System.out.println("2. View all payments");
            System.out.println("3. Search payment by Payment ID");
            System.out.println("4. Search payments by Parking Record ID");
            System.out.println("5. Search payments by Vehicle Registration Number");
            System.out.println("6. View Successful payments");
            System.out.println("7. View Pending / Unpaid parking sessions");
            System.out.println("8. View Failed payments");
            System.out.println("0. Back to Main Menu");
            int choice = readInt("Enter choice: ");

            switch (choice) {
                case 1:
                    int recId = readInt("Enter Parking Record ID to pay for: ");
                    ParkingRecord pr = parkingRecordDAO.getRecordById(recId);
                    if (pr == null) {
                        System.out.println("Parking Record #" + recId + " does not exist.");
                        break;
                    }
                    if ("Active".equalsIgnoreCase(pr.getStatus())) {
                        System.out.println("This vehicle is still parked. Please complete Vehicle Exit first to compute total fee.");
                        break;
                    }
                    if (paymentDAO.hasSuccessfulPayment(recId)) {
                        System.out.println("Notice: Parking Record #" + recId + " is ALREADY marked as Paid (Successful payment exists).");
                        break;
                    }
                    recordPaymentPrompt(recId, pr.getFee(), pr.getRegistrationNumber());
                    break;
                case 2:
                    paymentDAO.viewAllPayments();
                    break;
                case 3:
                    int pId = readInt("Enter Payment ID: ");
                    paymentDAO.searchByPaymentId(pId);
                    break;
                case 4:
                    int rId = readInt("Enter Parking Record ID: ");
                    paymentDAO.searchByRecordId(rId);
                    break;
                case 5:
                    String reg = readNonEmptyLine("Enter Vehicle Registration Number: ");
                    paymentDAO.searchByRegNumber(reg);
                    break;
                case 6:
                    paymentDAO.viewPaymentsByStatus("Successful");
                    break;
                case 7:
                    paymentDAO.viewPendingParkingFees();
                    break;
                case 8:
                    paymentDAO.viewPaymentsByStatus("Failed");
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void recordPaymentPrompt(int recordId, double expectedAmount, String regNumber) {
        System.out.println("\n---------------- RECORD PAYMENT ----------------");
        System.out.println(" Parking Record ID: " + recordId);
        System.out.println(" Vehicle Number   : " + regNumber);
        System.out.printf(" Due Amount       : Rs. %.2f%n", expectedAmount);

        double amount = readDouble("Enter payment amount (Rs) [default: " + expectedAmount + "]: ", expectedAmount);
        if (amount <= 0) {
            System.out.println("Payment amount must be greater than zero.");
            return;
        }

        String method = selectPaymentMethod();

        System.out.println("\nSelect Payment Result Status:");
        System.out.println("1. Successful (Payment Received)");
        System.out.println("2. Failed (Declined / Network Failure)");
        System.out.println("3. Pending (Awaiting confirmation)");
        int statChoice = readInt("Enter choice (1-3) [1]: ", 1);

        String status = "Successful";
        if (statChoice == 2) status = "Failed";
        else if (statChoice == 3) status = "Pending";

        String defaultRef = method.toUpperCase() + "-" + System.currentTimeMillis() % 1000000;
        String txnRef = readLineWithDefault("Enter Transaction Reference [" + defaultRef + "]: ", defaultRef);

        Payment payment = new Payment(recordId, amount, LocalDateTime.now(), method, status, txnRef);
        if (paymentDAO.recordPayment(payment)) {
            System.out.println("\n=======================================================");
            System.out.println("                    PAYMENT RECEIPT                    ");
            System.out.println("=======================================================");
            System.out.println(" Record ID     : " + recordId);
            System.out.println(" Vehicle Number: " + regNumber);
            System.out.printf(" Amount Paid   : Rs. %.2f%n", amount);
            System.out.println(" Payment Method: " + method);
            System.out.println(" Status        : " + status);
            System.out.println(" Reference ID  : " + txnRef);
            System.out.println(" Timestamp     : " + LocalDateTime.now().format(dtf));
            System.out.println("=======================================================");
            if ("Successful".equalsIgnoreCase(status)) {
                System.out.println(">>> Payment completed successfully!");
            } else {
                System.out.println(">>> Payment status saved as " + status + ".");
            }
        }
    }

    // ==========================================
    // 8. QUICK SEARCH VEHICLE
    // ==========================================
    private static void searchVehicleQuick() {
        System.out.println("\n--- SEARCH VEHICLE ---");
        String regNumber = readNonEmptyLine("Enter Vehicle Registration Number: ").toUpperCase();

        Vehicle v = vehicleDAO.getVehicleByRegNumber(regNumber);
        if (v == null) {
            System.out.println("No registered vehicle found with registration number: " + regNumber);
            return;
        }

        System.out.println("\n================ VEHICLE PROFILE ================");
        System.out.println(" Vehicle ID   : " + v.getVehicleId());
        System.out.println(" Reg Number   : " + v.getRegistrationNumber());
        System.out.println(" Type         : " + v.getVehicleType());
        System.out.println(" Owner Name   : " + v.getOwnerName());
        System.out.println(" Owner Phone  : " + v.getOwnerPhone());
        System.out.println(" Model        : " + (v.getModel() != null ? v.getModel() : "-"));
        System.out.println(" Reg Date     : " + v.getRegistrationDate().format(dtf));

        // Check if currently parked
        ParkingRecord active = parkingRecordDAO.findActiveRecord(regNumber);
        if (active != null) {
            System.out.println("\n[CURRENT STATUS: CURRENTLY PARKED]");
            System.out.println(" Parking Record : #" + active.getRecordId());
            System.out.println(" Parking Lot    : " + active.getLotName());
            System.out.println(" Slot Number    : " + active.getSlotNumber());
            System.out.println(" Entry Time     : " + active.getEntryTime().format(dtf));
        } else {
            System.out.println("\n[CURRENT STATUS: NOT CURRENTLY PARKED]");
        }
        System.out.println("=================================================");

        String showHist = readLine("View complete parking history for this vehicle? (y/n): ");
        if ("y".equalsIgnoreCase(showHist)) {
            vehicleDAO.viewParkingHistory(regNumber);
        }
    }

    // ==========================================
    // 6. VIEW PARKING RECORDS
    // ==========================================
    private static void viewParkingRecordsMenu() {
        while (true) {
            System.out.println("\n--- VIEW PARKING RECORDS ---");
            System.out.println("1. View all parking records");
            System.out.println("2. Search by parking record ID");
            System.out.println("3. Search by vehicle registration number");
            System.out.println("4. Search by parking lot");
            System.out.println("5. Search records by specific date (YYYY-MM-DD)");
            System.out.println("6. Search records within date range");
            System.out.println("7. View currently parked vehicles (Active)");
            System.out.println("8. View completed parking sessions");
            System.out.println("9. Custom filter (Status / Date / Vehicle Type / Lot)");
            System.out.println("0. Back to Main Menu");
            int choice = readInt("Enter choice: ");

            switch (choice) {
                case 1:
                    parkingRecordDAO.viewAllRecords();
                    break;
                case 2:
                    int id = readInt("Enter Parking Record ID: ");
                    parkingRecordDAO.searchById(id);
                    break;
                case 3:
                    String reg = readNonEmptyLine("Enter registration number: ");
                    parkingRecordDAO.searchByRegNumber(reg);
                    break;
                case 4:
                    int lotId = readInt("Enter Parking Lot ID: ");
                    parkingRecordDAO.searchByLot(lotId);
                    break;
                case 5:
                    String date = readNonEmptyLine("Enter date (YYYY-MM-DD): ");
                    parkingRecordDAO.searchByDate(date);
                    break;
                case 6:
                    String from = readNonEmptyLine("Enter from date (YYYY-MM-DD): ");
                    String to = readNonEmptyLine("Enter to date (YYYY-MM-DD): ");
                    parkingRecordDAO.searchByDateRange(from, to);
                    break;
                case 7:
                    parkingRecordDAO.viewCurrentlyParked();
                    break;
                case 8:
                    parkingRecordDAO.viewCompletedSessions();
                    break;
                case 9:
                    System.out.println("Leave blank to skip any filter.");
                    String stat = readLine("Status (Active / Completed / All): ");
                    String fDate = readLine("From Date (YYYY-MM-DD): ");
                    String tDate = readLine("To Date (YYYY-MM-DD): ");
                    String vType = readLine("Vehicle Type (Two-wheeler / Four-wheeler / Heavy vehicle): ");
                    String lotIdStr = readLine("Parking Lot ID: ");
                    Integer filterLot = null;
                    if (!lotIdStr.isEmpty()) {
                        try {
                            filterLot = Integer.parseInt(lotIdStr);
                        } catch (NumberFormatException ignored) {}
                    }
                    parkingRecordDAO.filterRecords(stat, fDate, tDate, vType, filterLot);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    // ==========================================
    // 9. REPORTS AND STATISTICS
    // ==========================================
    private static void reportsAndStatisticsMenu() {
        while (true) {
            System.out.println("\n========== REPORTS AND STATISTICS ==========");
            System.out.println("1.  View all registered vehicles");
            System.out.println("2.  View currently parked vehicles");
            System.out.println("3.  View completed parking sessions");
            System.out.println("4.  View parking history for a vehicle");
            System.out.println("5.  View parking records for a selected date");
            System.out.println("6.  View parking records within a date range");
            System.out.println("7.  Display total parking lots");
            System.out.println("8.  Display total parking slots");
            System.out.println("9.  Display available, occupied, and blocked slots count");
            System.out.println("10. Display number of registered vehicles by type");
            System.out.println("11. Calculate total parking fees generated");
            System.out.println("12. Calculate total successful payments collected");
            System.out.println("13. Display pending / outstanding payments");
            System.out.println("14. Display most frequently used parking lots");
            System.out.println("15. Display average parking duration");
            System.out.println("16. Display number of vehicles currently parked");
            System.out.println("17. View Pricing Rules Card");
            System.out.println("0.  Back to Main Menu");
            System.out.println("============================================");
            int choice = readInt("Enter report number (1-17, 0 to return): ");

            switch (choice) {
                case 1:
                    vehicleDAO.viewAllVehicles();
                    break;
                case 2:
                    parkingRecordDAO.viewCurrentlyParked();
                    break;
                case 3:
                    parkingRecordDAO.viewCompletedSessions();
                    break;
                case 4:
                    String reg = readNonEmptyLine("Enter Vehicle Registration Number: ");
                    vehicleDAO.viewParkingHistory(reg);
                    break;
                case 5:
                    String date = readNonEmptyLine("Enter date (YYYY-MM-DD): ");
                    parkingRecordDAO.searchByDate(date);
                    break;
                case 6:
                    String from = readNonEmptyLine("Enter From Date (YYYY-MM-DD): ");
                    String to = readNonEmptyLine("Enter To Date (YYYY-MM-DD): ");
                    parkingRecordDAO.searchByDateRange(from, to);
                    break;
                case 7:
                    System.out.println(">>> Total Parking Lots Registered: " + parkingLotDAO.getTotalLotsCount());
                    break;
                case 8:
                    System.out.println(">>> Total Parking Slots Registered: " + parkingSlotDAO.getTotalSlotsCount());
                    break;
                case 9:
                    int avail = parkingSlotDAO.getSlotCountByStatus("Available");
                    int occ = parkingSlotDAO.getSlotCountByStatus("Occupied");
                    int blk = parkingSlotDAO.getSlotCountByStatus("Blocked");
                    int total = avail + occ + blk;
                    System.out.println("\nSlot Status Breakdown:");
                    System.out.println("  Available Slots: " + avail);
                    System.out.println("  Occupied Slots : " + occ);
                    System.out.println("  Blocked Slots  : " + blk);
                    System.out.println("  Total Slots    : " + total);
                    break;
                case 10:
                    vehicleDAO.displayVehiclesByTypeCount();
                    break;
                case 11:
                    double totalFees = parkingRecordDAO.getTotalFeesGenerated();
                    System.out.printf(">>> Total Parking Fees Generated (Completed Sessions): Rs. %.2f%n", totalFees);
                    break;
                case 12:
                    double totalRevenue = paymentDAO.getTotalSuccessfulRevenue();
                    System.out.printf(">>> Total Successful Revenue Collected: Rs. %.2f%n", totalRevenue);
                    break;
                case 13:
                    paymentDAO.viewPendingParkingFees();
                    break;
                case 14:
                    parkingRecordDAO.displayMostFrequentlyUsedLots();
                    break;
                case 15:
                    double avgHrs = parkingRecordDAO.getAverageParkingDurationHours();
                    System.out.printf(">>> Average Parking Duration: %.2f hours%n", avgHrs);
                    break;
                case 16:
                    int parkedCount = parkingRecordDAO.getCurrentlyParkedCount();
                    System.out.println(">>> Number of vehicles currently parked: " + parkedCount);
                    break;
                case 17:
                    FeeCalculator.displayPricingRules();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid report number.");
            }
        }
    }

    // ==========================================
    // 10. PARKING AVAILABILITY MENU
    // ==========================================
    private static void parkingAvailabilityMenu() {
        while (true) {
            System.out.println("\n========== PARKING AVAILABILITY ==========");
            System.out.println("1. View all parking lots and capacities");
            System.out.println("2. View available slots in each parking lot");
            System.out.println("3. View occupied slots");
            System.out.println("4. View blocked slots");
            System.out.println("5. View availability by vehicle type");
            System.out.println("6. Search available parking slots by location");
            System.out.println("7. Display complete availability summary dashboard");
            System.out.println("0. Back to Main Menu");
            System.out.println("==========================================");
            int choice = readInt("Enter choice: ");

            switch (choice) {
                case 1:
                    parkingLotDAO.viewAllLots();
                    break;
                case 2:
                    parkingSlotDAO.displaySlotsByStatus("Available");
                    break;
                case 3:
                    parkingSlotDAO.displaySlotsByStatus("Occupied");
                    break;
                case 4:
                    parkingSlotDAO.displaySlotsByStatus("Blocked");
                    break;
                case 5:
                    parkingSlotDAO.displayAvailabilityByType();
                    break;
                case 6:
                    String loc = readNonEmptyLine("Enter location: ");
                    parkingSlotDAO.searchAvailableSlotsByLocation(loc);
                    break;
                case 7:
                    parkingSlotDAO.displayAvailabilitySummary();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    // ==========================================
    // INPUT VALIDATION & SCANNER HELPERS
    // ==========================================
    static String readLine(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    static String readLineWithDefault(String prompt, String defaultVal) {
        System.out.print(prompt);
        String val = scanner.nextLine().trim();
        return val.isEmpty() ? defaultVal : val;
    }

    static String readNonEmptyLine(String prompt) {
        while (true) {
            System.out.print(prompt);
            String val = scanner.nextLine().trim();
            if (!val.isEmpty()) return val;
            System.out.println("Input cannot be empty. Please try again.");
        }
    }

    static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String val = scanner.nextLine().trim();
            try {
                return Integer.parseInt(val);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer.");
            }
        }
    }

    static int readInt(String prompt, int defaultVal) {
        while (true) {
            System.out.print(prompt);
            String val = scanner.nextLine().trim();
            if (val.isEmpty()) return defaultVal;
            try {
                return Integer.parseInt(val);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer.");
            }
        }
    }

    static int readPositiveInt(String prompt) {
        while (true) {
            int val = readInt(prompt);
            if (val > 0) return val;
            System.out.println("Value must be a positive number greater than 0.");
        }
    }

    static double readDouble(String prompt, double defaultVal) {
        while (true) {
            System.out.print(prompt);
            String val = scanner.nextLine().trim();
            if (val.isEmpty()) return defaultVal;
            try {
                return Double.parseDouble(val);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid decimal number.");
            }
        }
    }

    static String readPhone(String prompt) {
        while (true) {
            String phone = readNonEmptyLine(prompt);
            // Allow 7 to 15 digits
            if (phone.matches("^[0-9+ -]{7,15}$")) {
                return phone;
            }
            System.out.println("Please enter a valid phone number (7-15 digits).");
        }
    }

    static String selectVehicleType() {
        System.out.println("Select Vehicle Type:");
        System.out.println("1. Two-wheeler");
        System.out.println("2. Four-wheeler");
        System.out.println("3. Heavy vehicle");
        while (true) {
            int ch = readInt("Enter type (1-3) [2]: ", 2);
            if (ch == 1) return "Two-wheeler";
            if (ch == 2) return "Four-wheeler";
            if (ch == 3) return "Heavy vehicle";
            System.out.println("Invalid choice. Select 1, 2, or 3.");
        }
    }

    static String selectPaymentMethod() {
        System.out.println("Select Payment Method:");
        System.out.println("1. Cash");
        System.out.println("2. UPI");
        System.out.println("3. Card");
        System.out.println("4. Bank Transfer");
        while (true) {
            int ch = readInt("Enter method (1-4) [1]: ", 1);
            if (ch == 1) return "Cash";
            if (ch == 2) return "UPI";
            if (ch == 3) return "Card";
            if (ch == 4) return "Bank Transfer";
            System.out.println("Invalid choice. Select 1, 2, 3, or 4.");
        }
    }
}
