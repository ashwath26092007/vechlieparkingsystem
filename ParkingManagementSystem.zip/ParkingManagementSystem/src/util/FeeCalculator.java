package util;

// Utility class for calculating parking fees based on vehicle type and duration
public class FeeCalculator {

    // Configurable Hourly Rates (INR)
    public static double TWO_WHEELER_FIRST_HOUR = 20.0;
    public static double TWO_WHEELER_ADDITIONAL_HOUR = 10.0;

    public static double FOUR_WHEELER_FIRST_HOUR = 40.0;
    public static double FOUR_WHEELER_ADDITIONAL_HOUR = 20.0;

    public static double HEAVY_VEHICLE_FIRST_HOUR = 100.0;
    public static double HEAVY_VEHICLE_ADDITIONAL_HOUR = 50.0;

    /**
     * Calculates the fee given a vehicle type and parking duration in total minutes.
     * Partial hours are rounded UP to the next full hour.
     * Short stays (< 60 minutes) are billed at the first-hour rate.
     */
    public static double calculateFee(String vehicleType, long totalMinutes) {
        if (totalMinutes < 0) {
            totalMinutes = 0;
        }

        // Round up partial hours to complete hours. Minimum 1 hour billed.
        long billedHours;
        if (totalMinutes <= 0) {
            billedHours = 1;
        } else {
            billedHours = (long) Math.ceil(totalMinutes / 60.0);
        }
        if (billedHours < 1) {
            billedHours = 1;
        }

        double firstHourRate;
        double additionalHourRate;

        if ("Two-wheeler".equalsIgnoreCase(vehicleType)) {
            firstHourRate = TWO_WHEELER_FIRST_HOUR;
            additionalHourRate = TWO_WHEELER_ADDITIONAL_HOUR;
        } else if ("Heavy vehicle".equalsIgnoreCase(vehicleType)) {
            firstHourRate = HEAVY_VEHICLE_FIRST_HOUR;
            additionalHourRate = HEAVY_VEHICLE_ADDITIONAL_HOUR;
        } else {
            // Default to Four-wheeler
            firstHourRate = FOUR_WHEELER_FIRST_HOUR;
            additionalHourRate = FOUR_WHEELER_ADDITIONAL_HOUR;
        }

        if (billedHours <= 1) {
            return firstHourRate;
        } else {
            return firstHourRate + ((billedHours - 1) * additionalHourRate);
        }
    }

    /**
     * Calculates billed hours from minutes (rounded up).
     */
    public static int calculateBilledHours(long totalMinutes) {
        if (totalMinutes <= 0) return 1;
        return (int) Math.ceil(totalMinutes / 60.0);
    }

    /**
     * Prints the active pricing card.
     */
    public static void displayPricingRules() {
        System.out.println("================== PARKING FEE RATES ==================");
        System.out.printf("%-16s | %-15s | %-18s%n", "Vehicle Type", "First Hour", "Additional Hour");
        System.out.println("-------------------------------------------------------");
        System.out.printf("%-16s | Rs. %-11.2f | Rs. %-14.2f%n", "Two-wheeler", TWO_WHEELER_FIRST_HOUR, TWO_WHEELER_ADDITIONAL_HOUR);
        System.out.printf("%-16s | Rs. %-11.2f | Rs. %-14.2f%n", "Four-wheeler", FOUR_WHEELER_FIRST_HOUR, FOUR_WHEELER_ADDITIONAL_HOUR);
        System.out.printf("%-16s | Rs. %-11.2f | Rs. %-14.2f%n", "Heavy vehicle", HEAVY_VEHICLE_FIRST_HOUR, HEAVY_VEHICLE_ADDITIONAL_HOUR);
        System.out.println("-------------------------------------------------------");
        System.out.println("Note: Any partial hour is rounded UP to a full hour.");
        System.out.println("=======================================================");
    }
}
