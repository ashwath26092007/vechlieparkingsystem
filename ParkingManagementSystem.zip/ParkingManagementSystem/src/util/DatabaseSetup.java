package util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

// Creates all tables and initial sample data automatically on the first application run.
// Ensures idempotent execution: never duplicates records or overwrites existing user data.
public class DatabaseSetup {

        public static void main(String[] args) {
                System.out.println("Running DatabaseSetup...");
                boolean success = init();
                System.out.println("DatabaseSetup completed. Success = " + success);
        }

        public static boolean init() {
                try (Connection con = DBConnection.getConnection();
                                Statement st = con.createStatement()) {

                        // 1. Create admin table
                        st.executeUpdate("CREATE TABLE IF NOT EXISTS admin ("
                                        + "username VARCHAR(30) PRIMARY KEY, "
                                        + "password VARCHAR(30) NOT NULL)");

                        // 2. Create parking_lot table
                        st.executeUpdate("CREATE TABLE IF NOT EXISTS parking_lot ("
                                        + "lot_id INT AUTO_INCREMENT PRIMARY KEY, "
                                        + "lot_name VARCHAR(60) NOT NULL, "
                                        + "location VARCHAR(60) NOT NULL, "
                                        + "address VARCHAR(150), "
                                        + "total_capacity INT NOT NULL, "
                                        + "opening_time VARCHAR(10) NOT NULL DEFAULT '06:00 AM', "
                                        + "closing_time VARCHAR(10) NOT NULL DEFAULT '11:00 PM', "
                                        + "status VARCHAR(15) NOT NULL DEFAULT 'Active')");

                        // 3. Create parking_slot table
                        st.executeUpdate("CREATE TABLE IF NOT EXISTS parking_slot ("
                                        + "slot_id INT AUTO_INCREMENT PRIMARY KEY, "
                                        + "lot_id INT NOT NULL, "
                                        + "slot_number VARCHAR(20) NOT NULL, "
                                        + "slot_type VARCHAR(20) NOT NULL, "
                                        + "slot_status VARCHAR(15) NOT NULL DEFAULT 'Available', "
                                        + "CONSTRAINT fk_slot_lot FOREIGN KEY (lot_id) REFERENCES parking_lot(lot_id) ON DELETE RESTRICT, "
                                        + "CONSTRAINT uk_lot_slot UNIQUE (lot_id, slot_number))");

                        // 4. Create vehicle table
                        st.executeUpdate("CREATE TABLE IF NOT EXISTS vehicle ("
                                        + "vehicle_id INT AUTO_INCREMENT PRIMARY KEY, "
                                        + "reg_number VARCHAR(20) NOT NULL UNIQUE, "
                                        + "vehicle_type VARCHAR(20) NOT NULL, "
                                        + "owner_name VARCHAR(60) NOT NULL, "
                                        + "owner_phone VARCHAR(15) NOT NULL, "
                                        + "vehicle_model VARCHAR(50), "
                                        + "registration_date DATETIME NOT NULL)");

                        // 5. Create parking_record table
                        st.executeUpdate("CREATE TABLE IF NOT EXISTS parking_record ("
                                        + "record_id INT AUTO_INCREMENT PRIMARY KEY, "
                                        + "vehicle_id INT NOT NULL, "
                                        + "lot_id INT NOT NULL, "
                                        + "slot_id INT NOT NULL, "
                                        + "entry_time DATETIME NOT NULL, "
                                        + "exit_time DATETIME NULL, "
                                        + "duration_hours INT DEFAULT 0, "
                                        + "fee DOUBLE NOT NULL DEFAULT 0.0, "
                                        + "parking_status VARCHAR(15) NOT NULL DEFAULT 'Active', "
                                        + "CONSTRAINT fk_record_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicle(vehicle_id) ON DELETE RESTRICT, "
                                        + "CONSTRAINT fk_record_lot FOREIGN KEY (lot_id) REFERENCES parking_lot(lot_id) ON DELETE RESTRICT, "
                                        + "CONSTRAINT fk_record_slot FOREIGN KEY (slot_id) REFERENCES parking_slot(slot_id) ON DELETE RESTRICT)");

                        // 6. Create payment table
                        st.executeUpdate("CREATE TABLE IF NOT EXISTS payment ("
                                        + "payment_id INT AUTO_INCREMENT PRIMARY KEY, "
                                        + "record_id INT NOT NULL, "
                                        + "amount DOUBLE NOT NULL, "
                                        + "payment_time DATETIME NOT NULL, "
                                        + "payment_method VARCHAR(20) NOT NULL, "
                                        + "payment_status VARCHAR(15) NOT NULL DEFAULT 'Pending', "
                                        + "transaction_ref VARCHAR(50), "
                                        + "CONSTRAINT fk_payment_record FOREIGN KEY (record_id) REFERENCES parking_record(record_id) ON DELETE RESTRICT)");

                        // Ensure default admin exists (idempotent check)
                        ResultSet rsAdmin = st.executeQuery("SELECT COUNT(*) FROM admin WHERE username = 'admin'");
                        rsAdmin.next();
                        if (rsAdmin.getInt(1) == 0) {
                                st.executeUpdate("INSERT INTO admin (username, password) VALUES ('admin', 'admin123')");
                        }

                        // Insert sample initial dataset only if parking_lot is empty
                        ResultSet rsLots = st.executeQuery("SELECT COUNT(*) FROM parking_lot");
                        rsLots.next();
                        if (rsLots.getInt(1) == 0) {
                                // Insert Sample Parking Lots
                                st.executeUpdate(
                                                "INSERT INTO parking_lot (lot_name, location, address, total_capacity, opening_time, closing_time, status) VALUES "
                                                                + "('Central City Plaza', 'Downtown', '101 MG Road, Downtown', 30, '06:00 AM', '11:00 PM', 'Active'), "
                                                                + "('Metro Express Hub', 'Metro Gate 2', 'Station Road, North Sector', 25, '24 Hours', '24 Hours', 'Active'), "
                                                                + "('Tech Corridor Hub', 'Electronic City', 'Phase 1 Expressway', 50, '24 Hours', '24 Hours', 'Active')");

                                // Insert Sample Parking Slots
                                st.executeUpdate(
                                                "INSERT INTO parking_slot (lot_id, slot_number, slot_type, slot_status) VALUES "
                                                                + "(1, 'S001', 'Two-wheeler', 'Available'), "
                                                                + "(1, 'S002', 'Two-wheeler', 'Available'), "
                                                                + "(1, 'S003', 'Four-wheeler', 'Available'), "
                                                                + "(1, 'S004', 'Four-wheeler', 'Available'), "
                                                                + "(1, 'S005', 'Heavy vehicle', 'Available'), "
                                                                + "(2, 'M001', 'Two-wheeler', 'Available'), "
                                                                + "(2, 'M002', 'Four-wheeler', 'Available'), "
                                                                + "(2, 'M003', 'Four-wheeler', 'Available'), "
                                                                + "(2, 'M004', 'Heavy vehicle', 'Available'), "
                                                                + "(3, 'T001', 'Two-wheeler', 'Available'), "
                                                                + "(3, 'T002', 'Four-wheeler', 'Available'), "
                                                                + "(3, 'T003', 'Heavy vehicle', 'Available')");

                                // Insert Sample Vehicles
                                st.executeUpdate(
                                                "INSERT INTO vehicle (reg_number, vehicle_type, owner_name, owner_phone, vehicle_model, registration_date) VALUES "
                                                                + "('KA01AB1234', 'Four-wheeler', 'Rahul Sharma', '9876543210', 'Hyundai Creta', NOW()), "
                                                                + "('TN07CD5678', 'Two-wheeler', 'Sneha Patel', '9123456780', 'Honda Activa', NOW()), "
                                                                + "('DL03EF9012', 'Heavy vehicle', 'Rajesh Singh', '9988776655', 'Tata 407', NOW())");

                                // Insert sample completed parking record and payment for immediate report
                                // visibility
                                st.executeUpdate(
                                                "INSERT INTO parking_record (vehicle_id, lot_id, slot_id, entry_time, exit_time, duration_hours, fee, parking_status) VALUES "
                                                                + "(2, 1, 1, DATE_SUB(NOW(), INTERVAL 3 HOUR), DATE_SUB(NOW(), INTERVAL 1 HOUR), 2, 30.0, 'Completed')");

                                st.executeUpdate(
                                                "INSERT INTO payment (record_id, amount, payment_time, payment_method, payment_status, transaction_ref) VALUES "
                                                                + "(1, 30.0, DATE_SUB(NOW(), INTERVAL 1 HOUR), 'UPI', 'Successful', 'UPI-DEMO-98231')");

                                System.out.println(
                                                "[DatabaseSetup] Initialized database and loaded sample demonstration data.");
                        }

                        return true;
                } catch (SQLException e) {
                        System.err.println("\n[DatabaseSetup] Error initializing database: " + e.getMessage());
                        System.err.println(
                                        "Please check that MySQL service is running and credentials in db.properties are valid.");
                        return false;
                }
        }
}
