package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

// Connects to MySQL database.
// Automatically discovers credentials via:
// 1. Environment variables (DB_USER, DB_PASSWORD, DB_HOST, DB_PORT)
// 2. System properties (-Ddb.user, -Ddb.password, -Ddb.host, -Ddb.port)
// 3. Persistent db.properties configuration file
// 4. Known standard local credentials (root, 1234, blank, admin)
// 5. Interactive console prompt fallback with automatic persistence
public class DBConnection {

    private static final String DEFAULT_HOST = "localhost";
    private static final String DEFAULT_PORT = "3306";
    private static final String DB_NAME = "parking_management_db";
    private static final String CONFIG_FILE = "db.properties";

    private static String resolvedHost = DEFAULT_HOST;
    private static String resolvedPort = DEFAULT_PORT;
    private static String resolvedUser = null;
    private static String resolvedPassword = null;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("Warning: MySQL JDBC Driver not found on classpath.");
        }
    }

    private static String buildUrl(String host, String port) {
        return "jdbc:mysql://" + host + ":" + port + "/" + DB_NAME
                + "?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    }

    public static Connection getConnection() throws SQLException {
        if (resolvedUser != null && resolvedPassword != null) {
            try {
                return DriverManager.getConnection(buildUrl(resolvedHost, resolvedPort), resolvedUser, resolvedPassword);
            } catch (SQLException e) {
                // If cached credentials fail, reset and re-resolve
                resolvedUser = null;
                resolvedPassword = null;
            }
        }
        return establishConnection();
    }

    private static synchronized Connection establishConnection() throws SQLException {
        if (resolvedUser != null && resolvedPassword != null) {
            return DriverManager.getConnection(buildUrl(resolvedHost, resolvedPort), resolvedUser, resolvedPassword);
        }

        // 1. Try Environment Variables
        String envHost = System.getenv("DB_HOST");
        String envPort = System.getenv("DB_PORT");
        String envUser = System.getenv("DB_USER");
        String envPass = System.getenv("DB_PASSWORD");
        if (envHost != null && !envHost.trim().isEmpty()) resolvedHost = envHost.trim();
        if (envPort != null && !envPort.trim().isEmpty()) resolvedPort = envPort.trim();

        if (envUser != null && envPass != null) {
            try {
                Connection con = DriverManager.getConnection(buildUrl(resolvedHost, resolvedPort), envUser, envPass);
                resolvedUser = envUser;
                resolvedPassword = envPass;
                saveConfig(resolvedHost, resolvedPort, envUser, envPass);
                return con;
            } catch (SQLException ignored) {
            }
        }

        // 2. Try explicit System properties (e.g. from run.bat or java -Ddb.user=...)
        String sysHost = System.getProperty("db.host");
        String sysPort = System.getProperty("db.port");
        String sysUser = System.getProperty("db.user");
        String sysPass = System.getProperty("db.password");
        if (sysHost != null && !sysHost.trim().isEmpty()) resolvedHost = sysHost.trim();
        if (sysPort != null && !sysPort.trim().isEmpty()) resolvedPort = sysPort.trim();

        if (sysUser != null && sysPass != null) {
            try {
                Connection con = DriverManager.getConnection(buildUrl(resolvedHost, resolvedPort), sysUser, sysPass);
                resolvedUser = sysUser;
                resolvedPassword = sysPass;
                saveConfig(resolvedHost, resolvedPort, sysUser, sysPass);
                return con;
            } catch (SQLException ignored) {
            }
        }

        // 3. Try saved db.properties file
        Properties props = loadConfig();
        String fileHost = props.getProperty("db.host", resolvedHost);
        String filePort = props.getProperty("db.port", resolvedPort);
        String fileUser = props.getProperty("db.user");
        String filePass = props.getProperty("db.password");
        resolvedHost = fileHost;
        resolvedPort = filePort;

        if (fileUser != null && filePass != null) {
            try {
                Connection con = DriverManager.getConnection(buildUrl(resolvedHost, resolvedPort), fileUser, filePass);
                resolvedUser = fileUser;
                resolvedPassword = filePass;
                return con;
            } catch (SQLException ignored) {
            }
        }

        // 4. Try common default credentials (including 1234, root, blank)
        String user = (fileUser != null && !fileUser.isEmpty()) ? fileUser : ((sysUser != null && !sysUser.isEmpty()) ? sysUser : "root");
        String[] candidatePasswords = {"1234", "root", "", "admin", "123456", "password"};
        for (String candidate : candidatePasswords) {
            try {
                Connection con = DriverManager.getConnection(buildUrl(resolvedHost, resolvedPort), user, candidate);
                resolvedUser = user;
                resolvedPassword = candidate;
                saveConfig(resolvedHost, resolvedPort, user, candidate);
                return con;
            } catch (SQLException ignored) {
            }
        }

        // 5. Interactive prompt in console if automatic detection fails
        System.out.println("\n[DBConnection] Could not auto-connect to MySQL with standard credentials.");
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter MySQL host [" + resolvedHost + "]: ");
        String inputHost = scanner.nextLine().trim();
        if (!inputHost.isEmpty()) resolvedHost = inputHost;

        System.out.print("Please enter MySQL port [" + resolvedPort + "]: ");
        String inputPort = scanner.nextLine().trim();
        if (!inputPort.isEmpty()) resolvedPort = inputPort;

        System.out.print("Please enter MySQL username [root]: ");
        String inputUser = scanner.nextLine().trim();
        if (inputUser.isEmpty()) inputUser = "root";

        System.out.print("Please enter MySQL password for " + inputUser + ": ");
        String inputPass = scanner.nextLine().trim();

        try {
            Connection con = DriverManager.getConnection(buildUrl(resolvedHost, resolvedPort), inputUser, inputPass);
            resolvedUser = inputUser;
            resolvedPassword = inputPass;
            saveConfig(resolvedHost, resolvedPort, inputUser, inputPass);
            return con;
        } catch (SQLException e) {
            System.err.println("Connection failed: " + e.getMessage());
            throw e;
        }
    }

    private static Properties loadConfig() {
        Properties props = new Properties();
        File file = new File(CONFIG_FILE);
        if (file.exists()) {
            try (FileInputStream fis = new FileInputStream(file)) {
                props.load(fis);
            } catch (IOException ignored) {
            }
        }
        return props;
    }

    private static void saveConfig(String host, String port, String user, String pass) {
        try {
            Properties props = new Properties();
            props.setProperty("db.host", host);
            props.setProperty("db.port", port);
            props.setProperty("db.user", user);
            props.setProperty("db.password", pass);
            try (FileOutputStream fos = new FileOutputStream(CONFIG_FILE)) {
                props.store(fos, "MySQL Connection Properties");
            }
        } catch (IOException ignored) {
        }
    }
}
