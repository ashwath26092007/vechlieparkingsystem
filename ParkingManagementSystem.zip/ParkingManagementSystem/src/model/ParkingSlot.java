package model;

// Model class representing a specific parking slot within a parking lot
public class ParkingSlot {
    private int slotId;
    private int lotId;
    private String slotNumber;
    private String slotType; // "Two-wheeler", "Four-wheeler", "Heavy vehicle"
    private String status;   // "Available", "Occupied", "Blocked"

    public ParkingSlot() {
    }

    public ParkingSlot(int lotId, String slotNumber, String slotType, String status) {
        this.lotId = lotId;
        this.slotNumber = slotNumber;
        this.slotType = slotType;
        this.status = status;
    }

    public ParkingSlot(int slotId, int lotId, String slotNumber, String slotType, String status) {
        this.slotId = slotId;
        this.lotId = lotId;
        this.slotNumber = slotNumber;
        this.slotType = slotType;
        this.status = status;
    }

    public int getSlotId() {
        return slotId;
    }

    public void setSlotId(int slotId) {
        this.slotId = slotId;
    }

    public int getLotId() {
        return lotId;
    }

    public void setLotId(int lotId) {
        this.lotId = lotId;
    }

    public String getSlotNumber() {
        return slotNumber;
    }

    public void setSlotNumber(String slotNumber) {
        this.slotNumber = slotNumber;
    }

    public String getSlotType() {
        return slotType;
    }

    public void setSlotType(String slotType) {
        this.slotType = slotType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
