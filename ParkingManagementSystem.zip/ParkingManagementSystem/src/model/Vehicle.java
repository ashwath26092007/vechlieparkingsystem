package model;

import java.time.LocalDateTime;

// Model class representing a vehicle registered in the system
public class Vehicle {
    private int vehicleId;
    private String registrationNumber;
    private String vehicleType; // "Two-wheeler", "Four-wheeler", "Heavy vehicle"
    private String ownerName;
    private String ownerPhone;
    private String model;
    private LocalDateTime registrationDate;

    public Vehicle() {
    }

    public Vehicle(String registrationNumber, String vehicleType, String ownerName,
                   String ownerPhone, String model, LocalDateTime registrationDate) {
        this.registrationNumber = registrationNumber;
        this.vehicleType = vehicleType;
        this.ownerName = ownerName;
        this.ownerPhone = ownerPhone;
        this.model = model;
        this.registrationDate = registrationDate;
    }

    public Vehicle(int vehicleId, String registrationNumber, String vehicleType, String ownerName,
                   String ownerPhone, String model, LocalDateTime registrationDate) {
        this.vehicleId = vehicleId;
        this.registrationNumber = registrationNumber;
        this.vehicleType = vehicleType;
        this.ownerName = ownerName;
        this.ownerPhone = ownerPhone;
        this.model = model;
        this.registrationDate = registrationDate;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerPhone() {
        return ownerPhone;
    }

    public void setOwnerPhone(String ownerPhone) {
        this.ownerPhone = ownerPhone;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public LocalDateTime getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(LocalDateTime registrationDate) {
        this.registrationDate = registrationDate;
    }
}
