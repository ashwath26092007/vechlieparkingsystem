package model;

// Model class representing a Parking Lot facility
public class ParkingLot {
    private int lotId;
    private String name;
    private String location;
    private String address;
    private int totalCapacity;
    private String openingTime;
    private String closingTime;
    private String status; // "Active" or "Inactive"

    public ParkingLot() {
    }

    public ParkingLot(String name, String location, String address, int totalCapacity,
                      String openingTime, String closingTime, String status) {
        this.name = name;
        this.location = location;
        this.address = address;
        this.totalCapacity = totalCapacity;
        this.openingTime = openingTime;
        this.closingTime = closingTime;
        this.status = status;
    }

    public ParkingLot(int lotId, String name, String location, String address, int totalCapacity,
                      String openingTime, String closingTime, String status) {
        this.lotId = lotId;
        this.name = name;
        this.location = location;
        this.address = address;
        this.totalCapacity = totalCapacity;
        this.openingTime = openingTime;
        this.closingTime = closingTime;
        this.status = status;
    }

    public int getLotId() {
        return lotId;
    }

    public void setLotId(int lotId) {
        this.lotId = lotId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getTotalCapacity() {
        return totalCapacity;
    }

    public void setTotalCapacity(int totalCapacity) {
        this.totalCapacity = totalCapacity;
    }

    public String getOpeningTime() {
        return openingTime;
    }

    public void setOpeningTime(String openingTime) {
        this.openingTime = openingTime;
    }

    public String getClosingTime() {
        return closingTime;
    }

    public void setClosingTime(String closingTime) {
        this.closingTime = closingTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
