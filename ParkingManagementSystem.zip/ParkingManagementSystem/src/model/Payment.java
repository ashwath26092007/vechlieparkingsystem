package model;

import java.time.LocalDateTime;

// Model class representing a payment transaction for a parking record
public class Payment {
    private int paymentId;
    private int recordId;
    private double amount;
    private LocalDateTime paymentTime;
    private String paymentMethod; // "Cash", "UPI", "Card", "Bank Transfer"
    private String status;        // "Pending", "Successful", "Failed", "Refunded"
    private String transactionRef;

    // Optional field for joined display
    private String registrationNumber;

    public Payment() {
    }

    public Payment(int recordId, double amount, LocalDateTime paymentTime,
                   String paymentMethod, String status, String transactionRef) {
        this.recordId = recordId;
        this.amount = amount;
        this.paymentTime = paymentTime;
        this.paymentMethod = paymentMethod;
        this.status = status;
        this.transactionRef = transactionRef;
    }

    public Payment(int paymentId, int recordId, double amount, LocalDateTime paymentTime,
                   String paymentMethod, String status, String transactionRef) {
        this.paymentId = paymentId;
        this.recordId = recordId;
        this.amount = amount;
        this.paymentTime = paymentTime;
        this.paymentMethod = paymentMethod;
        this.status = status;
        this.transactionRef = transactionRef;
    }

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public int getRecordId() {
        return recordId;
    }

    public void setRecordId(int recordId) {
        this.recordId = recordId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public LocalDateTime getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(LocalDateTime paymentTime) {
        this.paymentTime = paymentTime;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTransactionRef() {
        return transactionRef;
    }

    public void setTransactionRef(String transactionRef) {
        this.transactionRef = transactionRef;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }
}
