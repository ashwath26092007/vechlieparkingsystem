package model;

import java.time.LocalDateTime;

// Model class representing a vehicle parking transaction/session
public class ParkingRecord {
    private int recordId;
    private int vehicleId;
    private int lotId;
    private int slotId;
    private LocalDateTime entryTime;
    private LocalDateTime exitTime;
    private int durationHours;
    private double fee;
    private String status; // "Active", "Completed", "Cancelled"

    // Optional joined fields for easy display
    private String registrationNumber;
    private String vehicleType;
    private String lotName;
    private String slotNumber;
    private String paymentStatus;

    public ParkingRecord() {
    }

    public ParkingRecord(int vehicleId, int lotId, int slotId, LocalDateTime entryTime,
                         LocalDateTime exitTime, int durationHours, double fee, String status) {
        this.vehicleId = vehicleId;
        this.lotId = lotId;
        this.slotId = slotId;
        this.entryTime = entryTime;
        this.exitTime = exitTime;
        this.durationHours = durationHours;
        this.fee = fee;
        this.status = status;
    }

    public ParkingRecord(int recordId, int vehicleId, int lotId, int slotId, LocalDateTime entryTime,
                         LocalDateTime exitTime, int durationHours, double fee, String status) {
        this.recordId = recordId;
        this.vehicleId = vehicleId;
        this.lotId = lotId;
        this.slotId = slotId;
        this.entryTime = entryTime;
        this.exitTime = exitTime;
        this.durationHours = durationHours;
        this.fee = fee;
        this.status = status;
    }

    public int getRecordId() {
        return recordId;
    }

    public void setRecordId(int recordId) {
        this.recordId = recordId;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    public int getLotId() {
        return lotId;
    }

    public void setLotId(int lotId) {
        this.lotId = lotId;
    }

    public int getSlotId() {
        return slotId;
    }

    public void setSlotId(int slotId) {
        this.slotId = slotId;
    }

    public LocalDateTime getEntryTime() {
        return entryTime;
    }

    public void setEntryTime(LocalDateTime entryTime) {
        this.entryTime = entryTime;
    }

    public LocalDateTime getExitTime() {
        return exitTime;
    }

    public void setExitTime(LocalDateTime exitTime) {
        this.exitTime = exitTime;
    }

    public int getDurationHours() {
        return durationHours;
    }

    public void setDurationHours(int durationHours) {
        this.durationHours = durationHours;
    }

    public double getFee() {
        return fee;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getLotName() {
        return lotName;
    }

    public void setLotName(String lotName) {
        this.lotName = lotName;
    }

    public String getSlotNumber() {
        return slotNumber;
    }

    public void setSlotNumber(String slotNumber) {
        this.slotNumber = slotNumber;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }
}
