package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import model.Vehicle;
import util.DBConnection;

// DAO for managing vehicle registration and vehicle history records
public class VehicleDAO {

    public boolean registerVehicle(Vehicle v) {
        String regNumber = v.getRegistrationNumber().trim().toUpperCase();

        if (getVehicleByRegNumber(regNumber) != null) {
            System.out.println("Error: Vehicle with registration number '" + regNumber + "' is already registered.");
            return false;
        }

        String sql = "INSERT INTO vehicle (reg_number, vehicle_type, owner_name, owner_phone, vehicle_model, registration_date) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, regNumber);
            ps.setString(2, v.getVehicleType());
            ps.setString(3, v.getOwnerName());
            ps.setString(4, v.getOwnerPhone());
            ps.setString(5, v.getModel());
            LocalDateTime regDate = v.getRegistrationDate() != null ? v.getRegistrationDate() : LocalDateTime.now();
            ps.setTimestamp(6, Timestamp.valueOf(regDate));
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error registering vehicle: " + e.getMessage());
            return false;
        }
    }

    public void viewAllVehicles() {
        String sql = "SELECT * FROM vehicle ORDER BY vehicle_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            printVehicleRows(rs);
        } catch (SQLException e) {
            System.err.println("Error viewing all vehicles: " + e.getMessage());
        }
    }

    public Vehicle getVehicleByRegNumber(String regNumber) {
        String sql = "SELECT * FROM vehicle WHERE UPPER(reg_number) = UPPER(?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, regNumber.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching vehicle by registration number: " + e.getMessage());
        }
        return null;
    }

    public Vehicle getVehicleById(int vehicleId) {
        String sql = "SELECT * FROM vehicle WHERE vehicle_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, vehicleId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching vehicle by ID: " + e.getMessage());
        }
        return null;
    }

    public void searchByRegNumber(String regNumber) {
        String sql = "SELECT * FROM vehicle WHERE UPPER(reg_number) LIKE ? ORDER BY vehicle_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + regNumber.trim().toUpperCase() + "%");
            try (ResultSet rs = ps.executeQuery()) {
                printVehicleRows(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error searching vehicles: " + e.getMessage());
        }
    }

    public void searchByOwnerName(String ownerName) {
        String sql = "SELECT * FROM vehicle WHERE UPPER(owner_name) LIKE ? ORDER BY vehicle_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + ownerName.trim().toUpperCase() + "%");
            try (ResultSet rs = ps.executeQuery()) {
                printVehicleRows(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error searching vehicles by owner name: " + e.getMessage());
        }
    }

    public void searchByType(String vehicleType) {
        String sql = "SELECT * FROM vehicle WHERE UPPER(vehicle_type) LIKE ? ORDER BY vehicle_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + vehicleType.trim().toUpperCase() + "%");
            try (ResultSet rs = ps.executeQuery()) {
                printVehicleRows(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error searching vehicles by type: " + e.getMessage());
        }
    }

    public boolean updateVehicle(Vehicle v) {
        String sql = "UPDATE vehicle SET vehicle_type = ?, owner_name = ?, owner_phone = ?, vehicle_model = ? WHERE vehicle_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, v.getVehicleType());
            ps.setString(2, v.getOwnerName());
            ps.setString(3, v.getOwnerPhone());
            ps.setString(4, v.getModel());
            ps.setInt(5, v.getVehicleId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating vehicle: " + e.getMessage());
            return false;
        }
    }

    public void viewParkingHistory(String regNumber) {
        String sql = "SELECT r.record_id, v.reg_number, v.vehicle_type, l.lot_name, "
                + "s.slot_number, r.entry_time, r.exit_time, r.duration_hours, r.fee, r.parking_status "
                + "FROM parking_record r "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "JOIN parking_lot l ON r.lot_id = l.lot_id "
                + "JOIN parking_slot s ON r.slot_id = s.slot_id "
                + "WHERE UPPER(v.reg_number) = UPPER(?) "
                + "ORDER BY r.entry_time DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, regNumber.trim());
            try (ResultSet rs = ps.executeQuery()) {
                System.out.println("========================== PARKING HISTORY FOR " + regNumber.toUpperCase() + " ==========================");
                System.out.printf("%-6s | %-16s | %-8s | %-19s | %-19s | %-8s | %-10s | %-10s%n",
                        "Rec ID", "Lot Name", "Slot", "Entry Time", "Exit Time", "Duration", "Fee (Rs)", "Status");
                System.out.println("----------------------------------------------------------------------------------------------------------------");
                boolean found = false;
                while (rs.next()) {
                    found = true;
                    Timestamp exitTs = rs.getTimestamp("exit_time");
                    String exitStr = exitTs != null ? exitTs.toString().substring(0, 19) : "Still Parked";
                    System.out.printf("%-6d | %-16s | %-8s | %-19s | %-19s | %-8d | %-10.2f | %-10s%n",
                            rs.getInt("record_id"),
                            rs.getString("lot_name"),
                            rs.getString("slot_number"),
                            rs.getTimestamp("entry_time").toString().substring(0, 19),
                            exitStr,
                            rs.getInt("duration_hours"),
                            rs.getDouble("fee"),
                            rs.getString("parking_status"));
                }
                if (!found) {
                    System.out.println("No parking records found for vehicle " + regNumber.toUpperCase());
                }
                System.out.println("================================================================================================================");
            }
        } catch (SQLException e) {
            System.err.println("Error viewing parking history: " + e.getMessage());
        }
    }

    public int getTotalVehiclesCount() {
        String sql = "SELECT COUNT(*) FROM vehicle";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("Error counting vehicles: " + e.getMessage());
        }
        return 0;
    }

    public void displayVehiclesByTypeCount() {
        String sql = "SELECT vehicle_type, COUNT(*) AS count FROM vehicle GROUP BY vehicle_type ORDER BY vehicle_type";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            System.out.println("======== REGISTERED VEHICLES BY TYPE ========");
            System.out.printf("%-18s | %-10s%n", "Vehicle Type", "Total Count");
            System.out.println("---------------------------------------------");
            boolean found = false;
            while (rs.next()) {
                found = true;
                System.out.printf("%-18s | %-10d%n", rs.getString("vehicle_type"), rs.getInt("count"));
            }
            if (!found) {
                System.out.println("No vehicles registered.");
            }
            System.out.println("=============================================");
        } catch (SQLException e) {
            System.err.println("Error displaying vehicles by type: " + e.getMessage());
        }
    }

    private Vehicle mapRow(ResultSet rs) throws SQLException {
        Timestamp ts = rs.getTimestamp("registration_date");
        LocalDateTime regDate = ts != null ? ts.toLocalDateTime() : LocalDateTime.now();
        return new Vehicle(
                rs.getInt("vehicle_id"),
                rs.getString("reg_number"),
                rs.getString("vehicle_type"),
                rs.getString("owner_name"),
                rs.getString("owner_phone"),
                rs.getString("vehicle_model"),
                regDate
        );
    }

    private void printVehicleRows(ResultSet rs) throws SQLException {
        System.out.printf("%-6s | %-15s | %-15s | %-18s | %-13s | %-15s%n",
                "ID", "Registration No", "Vehicle Type", "Owner Name", "Phone", "Model");
        System.out.println("---------------------------------------------------------------------------------------------");
        boolean found = false;
        while (rs.next()) {
            found = true;
            System.out.printf("%-6d | %-15s | %-15s | %-18s | %-13s | %-15s%n",
                    rs.getInt("vehicle_id"),
                    rs.getString("reg_number"),
                    rs.getString("vehicle_type"),
                    rs.getString("owner_name"),
                    rs.getString("owner_phone"),
                    rs.getString("vehicle_model") != null ? rs.getString("vehicle_model") : "-");
        }
        if (!found) {
            System.out.println("No vehicles found.");
        }
    }
}
