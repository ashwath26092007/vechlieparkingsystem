package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import model.ParkingRecord;
import util.DBConnection;

// DAO for managing vehicle entry, exit sessions, and parking record history
public class ParkingRecordDAO {

    /**
     * Executes vehicle entry inside a database transaction.
     * Atomically validates slot status, checks for active sessions,
     * creates the parking record, and marks the slot as 'Occupied'.
     * Returns the created record_id, or -1 on failure.
     */
    public int recordVehicleEntry(int vehicleId, int lotId, int slotId) {
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            try {
                // 1. Check if vehicle already has an active session
                String checkVehSql = "SELECT record_id FROM parking_record WHERE vehicle_id = ? AND parking_status = 'Active' FOR UPDATE";
                try (PreparedStatement psVeh = con.prepareStatement(checkVehSql)) {
                    psVeh.setInt(1, vehicleId);
                    try (ResultSet rs = psVeh.executeQuery()) {
                        if (rs.next()) {
                            System.out.println("Entry Rejected: Vehicle already has an active parking session (Record #" + rs.getInt("record_id") + ").");
                            con.rollback();
                            return -1;
                        }
                    }
                }

                // 2. Lock and verify slot is Available
                String checkSlotSql = "SELECT slot_status, slot_type FROM parking_slot WHERE slot_id = ? AND lot_id = ? FOR UPDATE";
                try (PreparedStatement psSlot = con.prepareStatement(checkSlotSql)) {
                    psSlot.setInt(1, slotId);
                    psSlot.setInt(2, lotId);
                    try (ResultSet rs = psSlot.executeQuery()) {
                        if (!rs.next()) {
                            System.out.println("Entry Rejected: Slot not found in the specified parking lot.");
                            con.rollback();
                            return -1;
                        }
                        String currentStatus = rs.getString("slot_status");
                        if (!"Available".equalsIgnoreCase(currentStatus)) {
                            System.out.println("Entry Rejected: Slot is currently " + currentStatus + ".");
                            con.rollback();
                            return -1;
                        }
                    }
                }

                // 3. Insert new parking record
                LocalDateTime now = LocalDateTime.now();
                int recordId = -1;
                String insertSql = "INSERT INTO parking_record (vehicle_id, lot_id, slot_id, entry_time, exit_time, duration_hours, fee, parking_status) "
                        + "VALUES (?, ?, ?, ?, NULL, 0, 0.0, 'Active')";
                try (PreparedStatement psInsert = con.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
                    psInsert.setInt(1, vehicleId);
                    psInsert.setInt(2, lotId);
                    psInsert.setInt(3, slotId);
                    psInsert.setTimestamp(4, Timestamp.valueOf(now));
                    psInsert.executeUpdate();
                    try (ResultSet keys = psInsert.getGeneratedKeys()) {
                        if (keys.next()) {
                            recordId = keys.getInt(1);
                        }
                    }
                }

                // 4. Update slot status to 'Occupied'
                String updateSlotSql = "UPDATE parking_slot SET slot_status = 'Occupied' WHERE slot_id = ?";
                try (PreparedStatement psUpdate = con.prepareStatement(updateSlotSql)) {
                    psUpdate.setInt(1, slotId);
                    psUpdate.executeUpdate();
                }

                con.commit();
                return recordId;

            } catch (SQLException e) {
                con.rollback();
                System.err.println("Transaction rolled back due to error: " + e.getMessage());
                return -1;
            } finally {
                con.setAutoCommit(true);
            }
        } catch (SQLException e) {
            System.err.println("Database error during vehicle entry: " + e.getMessage());
            return -1;
        }
    }

    /**
     * Finds active parking record by vehicle registration number or parking record ID.
     */
    public ParkingRecord findActiveRecord(String identifier) {
        String sql = "SELECT r.*, v.reg_number, v.vehicle_type, l.lot_name, s.slot_number "
                + "FROM parking_record r "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "JOIN parking_lot l ON r.lot_id = l.lot_id "
                + "JOIN parking_slot s ON r.slot_id = s.slot_id "
                + "WHERE r.parking_status = 'Active' AND (UPPER(v.reg_number) = UPPER(?) OR CAST(r.record_id AS CHAR) = ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, identifier.trim());
            ps.setString(2, identifier.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ParkingRecord pr = mapRow(rs);
                    pr.setRegistrationNumber(rs.getString("reg_number"));
                    pr.setVehicleType(rs.getString("vehicle_type"));
                    pr.setLotName(rs.getString("lot_name"));
                    pr.setSlotNumber(rs.getString("slot_number"));
                    return pr;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error locating active parking record: " + e.getMessage());
        }
        return null;
    }

    /**
     * Executes vehicle exit inside a database transaction.
     * Completes the parking session, saves exit time, duration, and fee,
     * and releases the slot to 'Available'.
     */
    public boolean recordVehicleExit(int recordId, int slotId, LocalDateTime exitTime, int durationHours, double fee) {
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            try {
                // Verify record is active
                String checkSql = "SELECT parking_status FROM parking_record WHERE record_id = ? FOR UPDATE";
                try (PreparedStatement psCheck = con.prepareStatement(checkSql)) {
                    psCheck.setInt(1, recordId);
                    try (ResultSet rs = psCheck.executeQuery()) {
                        if (!rs.next() || !"Active".equalsIgnoreCase(rs.getString("parking_status"))) {
                            System.out.println("Exit error: Parking session is not active or already completed.");
                            con.rollback();
                            return false;
                        }
                    }
                }

                // Update parking record
                String updateRecSql = "UPDATE parking_record SET exit_time = ?, duration_hours = ?, fee = ?, parking_status = 'Completed' "
                        + "WHERE record_id = ?";
                try (PreparedStatement psRec = con.prepareStatement(updateRecSql)) {
                    psRec.setTimestamp(1, Timestamp.valueOf(exitTime));
                    psRec.setInt(2, durationHours);
                    psRec.setDouble(3, fee);
                    psRec.setInt(4, recordId);
                    psRec.executeUpdate();
                }

                // Release slot to Available
                String updateSlotSql = "UPDATE parking_slot SET slot_status = 'Available' WHERE slot_id = ?";
                try (PreparedStatement psSlot = con.prepareStatement(updateSlotSql)) {
                    psSlot.setInt(1, slotId);
                    psSlot.executeUpdate();
                }

                con.commit();
                return true;

            } catch (SQLException e) {
                con.rollback();
                System.err.println("Exit transaction failed and was rolled back: " + e.getMessage());
                return false;
            } finally {
                con.setAutoCommit(true);
            }
        } catch (SQLException e) {
            System.err.println("Database error during vehicle exit: " + e.getMessage());
            return false;
        }
    }

    public ParkingRecord getRecordById(int recordId) {
        String sql = "SELECT r.*, v.reg_number, v.vehicle_type, l.lot_name, s.slot_number "
                + "FROM parking_record r "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "JOIN parking_lot l ON r.lot_id = l.lot_id "
                + "JOIN parking_slot s ON r.slot_id = s.slot_id "
                + "WHERE r.record_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, recordId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ParkingRecord pr = mapRow(rs);
                    pr.setRegistrationNumber(rs.getString("reg_number"));
                    pr.setVehicleType(rs.getString("vehicle_type"));
                    pr.setLotName(rs.getString("lot_name"));
                    pr.setSlotNumber(rs.getString("slot_number"));
                    return pr;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching record by ID: " + e.getMessage());
        }
        return null;
    }

    public void viewAllRecords() {
        String sql = "SELECT r.*, v.reg_number, v.vehicle_type, l.lot_name, s.slot_number, "
                + "(SELECT p.payment_status FROM payment p WHERE p.record_id = r.record_id ORDER BY p.payment_id DESC LIMIT 1) AS pay_status "
                + "FROM parking_record r "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "JOIN parking_lot l ON r.lot_id = l.lot_id "
                + "JOIN parking_slot s ON r.slot_id = s.slot_id "
                + "ORDER BY r.record_id DESC";
        queryAndPrintRecords(sql);
    }

    public void searchById(int recordId) {
        String sql = "SELECT r.*, v.reg_number, v.vehicle_type, l.lot_name, s.slot_number, "
                + "(SELECT p.payment_status FROM payment p WHERE p.record_id = r.record_id ORDER BY p.payment_id DESC LIMIT 1) AS pay_status "
                + "FROM parking_record r "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "JOIN parking_lot l ON r.lot_id = l.lot_id "
                + "JOIN parking_slot s ON r.slot_id = s.slot_id "
                + "WHERE r.record_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, recordId);
            try (ResultSet rs = ps.executeQuery()) {
                printRecordTable(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error searching record by ID: " + e.getMessage());
        }
    }

    public void searchByRegNumber(String regNumber) {
        String sql = "SELECT r.*, v.reg_number, v.vehicle_type, l.lot_name, s.slot_number, "
                + "(SELECT p.payment_status FROM payment p WHERE p.record_id = r.record_id ORDER BY p.payment_id DESC LIMIT 1) AS pay_status "
                + "FROM parking_record r "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "JOIN parking_lot l ON r.lot_id = l.lot_id "
                + "JOIN parking_slot s ON r.slot_id = s.slot_id "
                + "WHERE UPPER(v.reg_number) LIKE ? "
                + "ORDER BY r.record_id DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + regNumber.trim().toUpperCase() + "%");
            try (ResultSet rs = ps.executeQuery()) {
                printRecordTable(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error searching records by registration number: " + e.getMessage());
        }
    }

    public void searchByLot(int lotId) {
        String sql = "SELECT r.*, v.reg_number, v.vehicle_type, l.lot_name, s.slot_number, "
                + "(SELECT p.payment_status FROM payment p WHERE p.record_id = r.record_id ORDER BY p.payment_id DESC LIMIT 1) AS pay_status "
                + "FROM parking_record r "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "JOIN parking_lot l ON r.lot_id = l.lot_id "
                + "JOIN parking_slot s ON r.slot_id = s.slot_id "
                + "WHERE r.lot_id = ? "
                + "ORDER BY r.record_id DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, lotId);
            try (ResultSet rs = ps.executeQuery()) {
                printRecordTable(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error searching records by lot: " + e.getMessage());
        }
    }

    public void searchByDate(String dateStr) {
        String sql = "SELECT r.*, v.reg_number, v.vehicle_type, l.lot_name, s.slot_number, "
                + "(SELECT p.payment_status FROM payment p WHERE p.record_id = r.record_id ORDER BY p.payment_id DESC LIMIT 1) AS pay_status "
                + "FROM parking_record r "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "JOIN parking_lot l ON r.lot_id = l.lot_id "
                + "JOIN parking_slot s ON r.slot_id = s.slot_id "
                + "WHERE DATE(r.entry_time) = ? "
                + "ORDER BY r.record_id DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, dateStr.trim());
            try (ResultSet rs = ps.executeQuery()) {
                printRecordTable(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error searching records by date: " + e.getMessage());
        }
    }

    public void searchByDateRange(String fromDate, String toDate) {
        String sql = "SELECT r.*, v.reg_number, v.vehicle_type, l.lot_name, s.slot_number, "
                + "(SELECT p.payment_status FROM payment p WHERE p.record_id = r.record_id ORDER BY p.payment_id DESC LIMIT 1) AS pay_status "
                + "FROM parking_record r "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "JOIN parking_lot l ON r.lot_id = l.lot_id "
                + "JOIN parking_slot s ON r.slot_id = s.slot_id "
                + "WHERE DATE(r.entry_time) BETWEEN ? AND ? "
                + "ORDER BY r.record_id DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, fromDate.trim());
            ps.setString(2, toDate.trim());
            try (ResultSet rs = ps.executeQuery()) {
                printRecordTable(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error searching records by date range: " + e.getMessage());
        }
    }

    public void viewCurrentlyParked() {
        String sql = "SELECT r.*, v.reg_number, v.vehicle_type, l.lot_name, s.slot_number, "
                + "'Pending' AS pay_status "
                + "FROM parking_record r "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "JOIN parking_lot l ON r.lot_id = l.lot_id "
                + "JOIN parking_slot s ON r.slot_id = s.slot_id "
                + "WHERE r.parking_status = 'Active' "
                + "ORDER BY r.entry_time ASC";
        queryAndPrintRecords(sql);
    }

    public void viewCompletedSessions() {
        String sql = "SELECT r.*, v.reg_number, v.vehicle_type, l.lot_name, s.slot_number, "
                + "(SELECT p.payment_status FROM payment p WHERE p.record_id = r.record_id ORDER BY p.payment_id DESC LIMIT 1) AS pay_status "
                + "FROM parking_record r "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "JOIN parking_lot l ON r.lot_id = l.lot_id "
                + "JOIN parking_slot s ON r.slot_id = s.slot_id "
                + "WHERE r.parking_status = 'Completed' "
                + "ORDER BY r.exit_time DESC";
        queryAndPrintRecords(sql);
    }

    public void filterRecords(String status, String fromDate, String toDate, String vehicleType, Integer lotId) {
        StringBuilder sb = new StringBuilder(
                "SELECT r.*, v.reg_number, v.vehicle_type, l.lot_name, s.slot_number, "
                        + "(SELECT p.payment_status FROM payment p WHERE p.record_id = r.record_id ORDER BY p.payment_id DESC LIMIT 1) AS pay_status "
                        + "FROM parking_record r "
                        + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                        + "JOIN parking_lot l ON r.lot_id = l.lot_id "
                        + "JOIN parking_slot s ON r.slot_id = s.slot_id WHERE 1=1 ");

        List<Object> params = new ArrayList<>();

        if (status != null && !status.isEmpty() && !"All".equalsIgnoreCase(status)) {
            sb.append("AND r.parking_status = ? ");
            params.add(status);
        }
        if (fromDate != null && !fromDate.isEmpty()) {
            sb.append("AND DATE(r.entry_time) >= ? ");
            params.add(fromDate);
        }
        if (toDate != null && !toDate.isEmpty()) {
            sb.append("AND DATE(r.entry_time) <= ? ");
            params.add(toDate);
        }
        if (vehicleType != null && !vehicleType.isEmpty() && !"All".equalsIgnoreCase(vehicleType)) {
            sb.append("AND UPPER(v.vehicle_type) = UPPER(?) ");
            params.add(vehicleType);
        }
        if (lotId != null && lotId > 0) {
            sb.append("AND r.lot_id = ? ");
            params.add(lotId);
        }

        sb.append("ORDER BY r.record_id DESC");

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sb.toString())) {
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                printRecordTable(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error filtering parking records: " + e.getMessage());
        }
    }

    public int getCurrentlyParkedCount() {
        String sql = "SELECT COUNT(*) FROM parking_record WHERE parking_status = 'Active'";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("Error counting currently parked vehicles: " + e.getMessage());
        }
        return 0;
    }

    public int getCompletedSessionsCount() {
        String sql = "SELECT COUNT(*) FROM parking_record WHERE parking_status = 'Completed'";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("Error counting completed sessions: " + e.getMessage());
        }
        return 0;
    }

    public double getTotalFeesGenerated() {
        String sql = "SELECT COALESCE(SUM(fee), 0) FROM parking_record WHERE parking_status = 'Completed'";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) {
            System.err.println("Error calculating total fees: " + e.getMessage());
        }
        return 0.0;
    }

    public double getAverageParkingDurationHours() {
        String sql = "SELECT COALESCE(AVG(duration_hours), 0) FROM parking_record WHERE parking_status = 'Completed'";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) {
            System.err.println("Error calculating average duration: " + e.getMessage());
        }
        return 0.0;
    }

    public void displayMostFrequentlyUsedLots() {
        String sql = "SELECT l.lot_name, l.location, COUNT(r.record_id) AS total_sessions, "
                + "COALESCE(SUM(r.fee), 0) AS total_revenue "
                + "FROM parking_record r "
                + "JOIN parking_lot l ON r.lot_id = l.lot_id "
                + "GROUP BY l.lot_id, l.lot_name, l.location "
                + "ORDER BY total_sessions DESC LIMIT 5";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            System.out.println("============== MOST FREQUENTLY USED PARKING LOTS ==============");
            System.out.printf("%-24s | %-16s | %-14s | %-12s%n", "Parking Lot", "Location", "Total Sessions", "Revenue (Rs)");
            System.out.println("-------------------------------------------------------------------------");
            boolean found = false;
            while (rs.next()) {
                found = true;
                System.out.printf("%-24s | %-16s | %-14d | %-12.2f%n",
                        rs.getString("lot_name"),
                        rs.getString("location"),
                        rs.getInt("total_sessions"),
                        rs.getDouble("total_revenue"));
            }
            if (!found) {
                System.out.println("No parking sessions recorded yet.");
            }
            System.out.println("=========================================================================");
        } catch (SQLException e) {
            System.err.println("Error displaying top lots: " + e.getMessage());
        }
    }

    private void queryAndPrintRecords(String sql) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            printRecordTable(rs);
        } catch (SQLException e) {
            System.err.println("Error querying records: " + e.getMessage());
        }
    }

    private void printRecordTable(ResultSet rs) throws SQLException {
        System.out.printf("%-6s | %-14s | %-13s | %-18s | %-6s | %-16s | %-16s | %-6s | %-8s | %-9s | %-8s%n",
                "Rec ID", "Reg No", "Type", "Lot Name", "Slot", "Entry Time", "Exit Time", "Hours", "Fee (Rs)", "Status", "Payment");
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------");
        boolean found = false;
        while (rs.next()) {
            found = true;
            Timestamp exitTs = rs.getTimestamp("exit_time");
            String exitStr = exitTs != null ? exitTs.toString().substring(0, 16) : "--";
            String payStatus = rs.getString("pay_status");
            if (payStatus == null) payStatus = "Active".equalsIgnoreCase(rs.getString("parking_status")) ? "--" : "Pending";

            System.out.printf("%-6d | %-14s | %-13s | %-18s | %-6s | %-16s | %-16s | %-6d | %-8.2f | %-9s | %-8s%n",
                    rs.getInt("record_id"),
                    rs.getString("reg_number"),
                    rs.getString("vehicle_type"),
                    rs.getString("lot_name"),
                    rs.getString("slot_number"),
                    rs.getTimestamp("entry_time").toString().substring(0, 16),
                    exitStr,
                    rs.getInt("duration_hours"),
                    rs.getDouble("fee"),
                    rs.getString("parking_status"),
                    payStatus);
        }
        if (!found) {
            System.out.println("No parking records found.");
        }
    }

    private ParkingRecord mapRow(ResultSet rs) throws SQLException {
        Timestamp exitTs = rs.getTimestamp("exit_time");
        LocalDateTime exitTime = exitTs != null ? exitTs.toLocalDateTime() : null;
        return new ParkingRecord(
                rs.getInt("record_id"),
                rs.getInt("vehicle_id"),
                rs.getInt("lot_id"),
                rs.getInt("slot_id"),
                rs.getTimestamp("entry_time").toLocalDateTime(),
                exitTime,
                rs.getInt("duration_hours"),
                rs.getDouble("fee"),
                rs.getString("parking_status")
        );
    }
}
