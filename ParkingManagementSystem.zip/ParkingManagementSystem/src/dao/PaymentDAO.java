package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import model.Payment;
import util.DBConnection;

// DAO for handling payment transactions, refunds, and financial auditing
public class PaymentDAO {

    public boolean recordPayment(Payment payment) {
        if (payment.getAmount() <= 0) {
            System.out.println("Invalid payment amount: Amount must be greater than zero.");
            return false;
        }

        // Check if there is already a successful payment for this parking record
        if ("Successful".equalsIgnoreCase(payment.getStatus()) && hasSuccessfulPayment(payment.getRecordId())) {
            System.out.println("Payment Rejected: Parking Record #" + payment.getRecordId() + " already has a successful payment.");
            return false;
        }

        String sql = "INSERT INTO payment (record_id, amount, payment_time, payment_method, payment_status, transaction_ref) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, payment.getRecordId());
            ps.setDouble(2, payment.getAmount());
            LocalDateTime payTime = payment.getPaymentTime() != null ? payment.getPaymentTime() : LocalDateTime.now();
            ps.setTimestamp(3, Timestamp.valueOf(payTime));
            ps.setString(4, payment.getPaymentMethod());
            ps.setString(5, payment.getStatus());
            ps.setString(6, payment.getTransactionRef());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error recording payment: " + e.getMessage());
            return false;
        }
    }

    public boolean hasSuccessfulPayment(int recordId) {
        String sql = "SELECT COUNT(*) FROM payment WHERE record_id = ? AND payment_status = 'Successful'";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, recordId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error checking payment status: " + e.getMessage());
        }
        return false;
    }

    public void viewAllPayments() {
        String sql = "SELECT p.*, v.reg_number "
                + "FROM payment p "
                + "JOIN parking_record r ON p.record_id = r.record_id "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "ORDER BY p.payment_id DESC";
        queryAndPrintPayments(sql);
    }

    public void searchByPaymentId(int paymentId) {
        String sql = "SELECT p.*, v.reg_number "
                + "FROM payment p "
                + "JOIN parking_record r ON p.record_id = r.record_id "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "WHERE p.payment_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, paymentId);
            try (ResultSet rs = ps.executeQuery()) {
                printPaymentTable(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error searching payment by ID: " + e.getMessage());
        }
    }

    public void searchByRecordId(int recordId) {
        String sql = "SELECT p.*, v.reg_number "
                + "FROM payment p "
                + "JOIN parking_record r ON p.record_id = r.record_id "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "WHERE p.record_id = ? "
                + "ORDER BY p.payment_id DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, recordId);
            try (ResultSet rs = ps.executeQuery()) {
                printPaymentTable(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error searching payment by record ID: " + e.getMessage());
        }
    }

    public void searchByRegNumber(String regNumber) {
        String sql = "SELECT p.*, v.reg_number "
                + "FROM payment p "
                + "JOIN parking_record r ON p.record_id = r.record_id "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "WHERE UPPER(v.reg_number) LIKE ? "
                + "ORDER BY p.payment_id DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + regNumber.trim().toUpperCase() + "%");
            try (ResultSet rs = ps.executeQuery()) {
                printPaymentTable(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error searching payment by registration number: " + e.getMessage());
        }
    }

    public void viewPaymentsByStatus(String status) {
        String sql = "SELECT p.*, v.reg_number "
                + "FROM payment p "
                + "JOIN parking_record r ON p.record_id = r.record_id "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "WHERE UPPER(p.payment_status) = UPPER(?) "
                + "ORDER BY p.payment_id DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                printPaymentTable(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error displaying payments by status: " + e.getMessage());
        }
    }

    public void viewPendingParkingFees() {
        // Completed parking records that do not have any successful payment
        String sql = "SELECT r.record_id, v.reg_number, r.fee, r.exit_time, l.lot_name "
                + "FROM parking_record r "
                + "JOIN vehicle v ON r.vehicle_id = v.vehicle_id "
                + "JOIN parking_lot l ON r.lot_id = l.lot_id "
                + "WHERE r.parking_status = 'Completed' "
                + "AND r.record_id NOT IN (SELECT record_id FROM payment WHERE payment_status = 'Successful') "
                + "ORDER BY r.exit_time DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            System.out.println("========================== PENDING UNPAID PARKING SESSIONS ==========================");
            System.out.printf("%-8s | %-15s | %-20s | %-12s | %-16s%n",
                    "Rec ID", "Reg Number", "Parking Lot", "Fee (Rs)", "Exit Time");
            System.out.println("-------------------------------------------------------------------------------------");
            boolean found = false;
            double totalPending = 0.0;
            while (rs.next()) {
                found = true;
                double fee = rs.getDouble("fee");
                totalPending += fee;
                Timestamp exitTs = rs.getTimestamp("exit_time");
                String exitStr = exitTs != null ? exitTs.toString().substring(0, 16) : "--";
                System.out.printf("%-8d | %-15s | %-20s | %-12.2f | %-16s%n",
                        rs.getInt("record_id"),
                        rs.getString("reg_number"),
                        rs.getString("lot_name"),
                        fee,
                        exitStr);
            }
            if (!found) {
                System.out.println("All completed parking sessions have been fully settled!");
            } else {
                System.out.println("-------------------------------------------------------------------------------------");
                System.out.printf("Total Outstanding Pending Amount: Rs. %.2f%n", totalPending);
            }
            System.out.println("=====================================================================================");
        } catch (SQLException e) {
            System.err.println("Error viewing pending parking fees: " + e.getMessage());
        }
    }

    public double getTotalSuccessfulRevenue() {
        String sql = "SELECT COALESCE(SUM(amount), 0) FROM payment WHERE payment_status = 'Successful'";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) {
            System.err.println("Error calculating revenue: " + e.getMessage());
        }
        return 0.0;
    }

    public double getTotalRefundedAmount() {
        String sql = "SELECT COALESCE(SUM(amount), 0) FROM payment WHERE payment_status = 'Refunded'";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) {
            System.err.println("Error calculating refunds: " + e.getMessage());
        }
        return 0.0;
    }

    public double getTotalPendingAmount() {
        String sql = "SELECT COALESCE(SUM(r.fee), 0) FROM parking_record r "
                + "WHERE r.parking_status = 'Completed' "
                + "AND r.record_id NOT IN (SELECT record_id FROM payment WHERE payment_status = 'Successful')";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) {
            System.err.println("Error calculating pending amount: " + e.getMessage());
        }
        return 0.0;
    }

    private void queryAndPrintPayments(String sql) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            printPaymentTable(rs);
        } catch (SQLException e) {
            System.err.println("Error querying payments: " + e.getMessage());
        }
    }

    private void printPaymentTable(ResultSet rs) throws SQLException {
        System.out.printf("%-8s | %-8s | %-14s | %-10s | %-16s | %-14s | %-11s | %-20s%n",
                "Pay ID", "Rec ID", "Reg Number", "Amount(Rs)", "Payment Time", "Method", "Status", "Reference");
        System.out.println("------------------------------------------------------------------------------------------------------------------------");
        boolean found = false;
        while (rs.next()) {
            found = true;
            Timestamp ts = rs.getTimestamp("payment_time");
            String timeStr = ts != null ? ts.toString().substring(0, 16) : "--";
            System.out.printf("%-8d | %-8d | %-14s | %-10.2f | %-16s | %-14s | %-11s | %-20s%n",
                    rs.getInt("payment_id"),
                    rs.getInt("record_id"),
                    rs.getString("reg_number"),
                    rs.getDouble("amount"),
                    timeStr,
                    rs.getString("payment_method"),
                    rs.getString("payment_status"),
                    rs.getString("transaction_ref") != null ? rs.getString("transaction_ref") : "-");
        }
        if (!found) {
            System.out.println("No payment transactions found.");
        }
    }
}
