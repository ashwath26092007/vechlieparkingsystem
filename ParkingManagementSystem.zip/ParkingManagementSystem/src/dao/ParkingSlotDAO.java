package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.ParkingSlot;
import util.DBConnection;

// DAO for managing parking slots within parking lots
public class ParkingSlotDAO {

    public boolean addSlot(ParkingSlot slot) {
        // Check duplicate slot number within lot
        if (slotExistsInLot(slot.getLotId(), slot.getSlotNumber())) {
            System.out.println("Error: Slot number '" + slot.getSlotNumber() + "' already exists in Lot #" + slot.getLotId());
            return false;
        }

        String sql = "INSERT INTO parking_slot (lot_id, slot_number, slot_type, slot_status) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, slot.getLotId());
            ps.setString(2, slot.getSlotNumber().toUpperCase());
            ps.setString(3, slot.getSlotType());
            ps.setString(4, slot.getStatus());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error adding parking slot: " + e.getMessage());
            return false;
        }
    }

    public boolean slotExistsInLot(int lotId, String slotNumber) {
        String sql = "SELECT COUNT(*) FROM parking_slot WHERE lot_id = ? AND UPPER(slot_number) = UPPER(?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, lotId);
            ps.setString(2, slotNumber.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error checking slot existence: " + e.getMessage());
        }
        return false;
    }

    public int generateSlots(int lotId, String prefix, int count, String slotType) {
        int created = 0;
        int candidateIndex = 1;

        String insertSql = "INSERT INTO parking_slot (lot_id, slot_number, slot_type, slot_status) VALUES (?, ?, ?, 'Available')";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement checkPs = con.prepareStatement("SELECT COUNT(*) FROM parking_slot WHERE lot_id = ? AND UPPER(slot_number) = ?");
             PreparedStatement insertPs = con.prepareStatement(insertSql)) {

            while (created < count && candidateIndex < 10000) {
                String candidateNumber = String.format("%s%03d", prefix.toUpperCase(), candidateIndex);
                candidateIndex++;

                checkPs.setInt(1, lotId);
                checkPs.setString(2, candidateNumber);
                try (ResultSet rs = checkPs.executeQuery()) {
                    if (rs.next() && rs.getInt(1) == 0) {
                        // Safe to insert
                        insertPs.setInt(1, lotId);
                        insertPs.setString(2, candidateNumber);
                        insertPs.setString(3, slotType);
                        insertPs.executeUpdate();
                        created++;
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error auto-generating slots: " + e.getMessage());
        }
        return created;
    }

    public void viewAllSlots() {
        String sql = "SELECT s.slot_id, s.lot_id, l.lot_name, s.slot_number, s.slot_type, s.slot_status "
                + "FROM parking_slot s "
                + "JOIN parking_lot l ON s.lot_id = l.lot_id "
                + "ORDER BY s.lot_id, s.slot_number";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            printSlotRows(rs);
        } catch (SQLException e) {
            System.err.println("Error viewing all slots: " + e.getMessage());
        }
    }

    public void viewSlotsByLot(int lotId) {
        String sql = "SELECT s.slot_id, s.lot_id, l.lot_name, s.slot_number, s.slot_type, s.slot_status "
                + "FROM parking_slot s "
                + "JOIN parking_lot l ON s.lot_id = l.lot_id "
                + "WHERE s.lot_id = ? "
                + "ORDER BY s.slot_number";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, lotId);
            try (ResultSet rs = ps.executeQuery()) {
                printSlotRows(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error viewing slots by lot: " + e.getMessage());
        }
    }

    public void searchSlot(String query) {
        String sql = "SELECT s.slot_id, s.lot_id, l.lot_name, s.slot_number, s.slot_type, s.slot_status "
                + "FROM parking_slot s "
                + "JOIN parking_lot l ON s.lot_id = l.lot_id "
                + "WHERE CAST(s.slot_id AS CHAR) = ? OR UPPER(s.slot_number) LIKE ? "
                + "ORDER BY s.slot_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, query);
            ps.setString(2, "%" + query.toUpperCase() + "%");
            try (ResultSet rs = ps.executeQuery()) {
                printSlotRows(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error searching slot: " + e.getMessage());
        }
    }

    public ParkingSlot getSlotById(int slotId) {
        String sql = "SELECT * FROM parking_slot WHERE slot_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, slotId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new ParkingSlot(
                            rs.getInt("slot_id"),
                            rs.getInt("lot_id"),
                            rs.getString("slot_number"),
                            rs.getString("slot_type"),
                            rs.getString("slot_status")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching slot by ID: " + e.getMessage());
        }
        return null;
    }

    public boolean updateSlot(ParkingSlot slot) {
        // Check if another slot in same lot uses the new slot number
        String checkSql = "SELECT COUNT(*) FROM parking_slot WHERE lot_id = ? AND UPPER(slot_number) = UPPER(?) AND slot_id != ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement checkPs = con.prepareStatement(checkSql)) {
            checkPs.setInt(1, slot.getLotId());
            checkPs.setString(2, slot.getSlotNumber().trim());
            checkPs.setInt(3, slot.getSlotId());
            try (ResultSet rs = checkPs.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {
                    System.out.println("Error: Slot number '" + slot.getSlotNumber() + "' is already in use in this lot.");
                    return false;
                }
            }

            String sql = "UPDATE parking_slot SET slot_number = ?, slot_type = ?, slot_status = ? WHERE slot_id = ?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, slot.getSlotNumber().toUpperCase());
                ps.setString(2, slot.getSlotType());
                ps.setString(3, slot.getStatus());
                ps.setInt(4, slot.getSlotId());
                return ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error updating slot: " + e.getMessage());
            return false;
        }
    }

    public boolean changeSlotStatus(int slotId, String newStatus) {
        ParkingSlot slot = getSlotById(slotId);
        if (slot == null) {
            System.out.println("Slot ID #" + slotId + " not found.");
            return false;
        }

        if ("Occupied".equalsIgnoreCase(slot.getStatus()) && !"Occupied".equalsIgnoreCase(newStatus)) {
            System.out.println("Cannot change status: Slot is currently Occupied by an active vehicle. Complete vehicle exit first.");
            return false;
        }

        String sql = "UPDATE parking_slot SET slot_status = ? WHERE slot_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, newStatus);
            ps.setInt(2, slotId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating slot status: " + e.getMessage());
            return false;
        }
    }

    public void displaySlotsByStatus(String status) {
        String sql = "SELECT s.slot_id, s.lot_id, l.lot_name, s.slot_number, s.slot_type, s.slot_status "
                + "FROM parking_slot s "
                + "JOIN parking_lot l ON s.lot_id = l.lot_id "
                + "WHERE UPPER(s.slot_status) = UPPER(?) "
                + "ORDER BY s.lot_id, s.slot_number";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                printSlotRows(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error displaying slots by status: " + e.getMessage());
        }
    }

    public boolean deleteSlot(int slotId) {
        ParkingSlot slot = getSlotById(slotId);
        if (slot == null) {
            System.out.println("Slot ID #" + slotId + " not found.");
            return false;
        }
        if ("Occupied".equalsIgnoreCase(slot.getStatus())) {
            System.out.println("Cannot delete slot: It is currently Occupied.");
            return false;
        }

        try (Connection con = DBConnection.getConnection()) {
            // Check active parking records
            String checkRecord = "SELECT COUNT(*) FROM parking_record WHERE slot_id = ? AND parking_status = 'Active'";
            try (PreparedStatement psCheck = con.prepareStatement(checkRecord)) {
                psCheck.setInt(1, slotId);
                try (ResultSet rs = psCheck.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        System.out.println("Cannot delete slot: It has active parking session(s).");
                        return false;
                    }
                }
            }

            // Check historical parking records
            String checkHist = "SELECT COUNT(*) FROM parking_record WHERE slot_id = ?";
            try (PreparedStatement psHist = con.prepareStatement(checkHist)) {
                psHist.setInt(1, slotId);
                try (ResultSet rs = psHist.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        System.out.println("Slot has historical parking records. It can be set to 'Blocked' instead of deleting to preserve record history.");
                        System.out.print("Do you still want to delete and break foreign key history? Not recommended. Block slot instead.");
                        return false;
                    }
                }
            }

            String sql = "DELETE FROM parking_slot WHERE slot_id = ?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, slotId);
                return ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error deleting slot: " + e.getMessage());
            return false;
        }
    }

    public List<ParkingSlot> getAvailableSlots(int lotId, String vehicleType) {
        List<ParkingSlot> list = new ArrayList<>();
        String sql = "SELECT * FROM parking_slot WHERE lot_id = ? AND UPPER(slot_type) = UPPER(?) AND slot_status = 'Available' ORDER BY slot_number";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, lotId);
            ps.setString(2, vehicleType);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new ParkingSlot(
                            rs.getInt("slot_id"),
                            rs.getInt("lot_id"),
                            rs.getString("slot_number"),
                            rs.getString("slot_type"),
                            rs.getString("slot_status")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching available slots: " + e.getMessage());
        }
        return list;
    }

    public int getTotalSlotsCount() {
        String sql = "SELECT COUNT(*) FROM parking_slot";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("Error counting total slots: " + e.getMessage());
        }
        return 0;
    }

    public int getSlotCountByStatus(String status) {
        String sql = "SELECT COUNT(*) FROM parking_slot WHERE UPPER(slot_status) = UPPER(?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("Error counting slots by status: " + e.getMessage());
        }
        return 0;
    }

    public void displayAvailabilitySummary() {
        String sql = "SELECT l.lot_id, l.lot_name, l.total_capacity, "
                + "SUM(CASE WHEN s.slot_status = 'Available' THEN 1 ELSE 0 END) AS available_count, "
                + "SUM(CASE WHEN s.slot_status = 'Occupied' THEN 1 ELSE 0 END) AS occupied_count, "
                + "SUM(CASE WHEN s.slot_status = 'Blocked' THEN 1 ELSE 0 END) AS blocked_count, "
                + "COUNT(s.slot_id) AS actual_slots "
                + "FROM parking_lot l "
                + "LEFT JOIN parking_slot s ON l.lot_id = s.lot_id "
                + "GROUP BY l.lot_id, l.lot_name, l.total_capacity "
                + "ORDER BY l.lot_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("================================ PARKING AVAILABILITY SUMMARY ================================");
            System.out.printf("%-6s | %-22s | %-10s | %-10s | %-10s | %-10s | %-12s%n",
                    "Lot ID", "Parking Lot", "Capacity", "Available", "Occupied", "Blocked", "Availability%");
            System.out.println("----------------------------------------------------------------------------------------------");

            int grandCapacity = 0;
            int grandAvailable = 0;
            int grandOccupied = 0;
            int grandBlocked = 0;
            boolean found = false;

            while (rs.next()) {
                found = true;
                int lotId = rs.getInt("lot_id");
                String name = rs.getString("lot_name");
                int cap = rs.getInt("total_capacity");
                int avail = rs.getInt("available_count");
                int occ = rs.getInt("occupied_count");
                int blk = rs.getInt("blocked_count");
                int actual = rs.getInt("actual_slots");

                int totalTracked = actual > 0 ? actual : cap;
                double availPct = totalTracked > 0 ? ((double) avail / totalTracked) * 100.0 : 0.0;

                grandCapacity += cap;
                grandAvailable += avail;
                grandOccupied += occ;
                grandBlocked += blk;

                System.out.printf("%-6d | %-22s | %-10d | %-10d | %-10d | %-10d | %-11.1f%%%n",
                        lotId, name, cap, avail, occ, blk, availPct);
            }
            if (!found) {
                System.out.println("No parking lots found.");
            } else {
                System.out.println("----------------------------------------------------------------------------------------------");
                int totalActiveSlots = grandAvailable + grandOccupied + grandBlocked;
                double grandPct = totalActiveSlots > 0 ? ((double) grandAvailable / totalActiveSlots) * 100.0 : 0.0;
                System.out.printf("%-31s | %-10d | %-10d | %-10d | %-10d | %-11.1f%%%n",
                        "TOTAL / SYSTEM-WIDE", grandCapacity, grandAvailable, grandOccupied, grandBlocked, grandPct);
            }
            System.out.println("==============================================================================================");
        } catch (SQLException e) {
            System.err.println("Error displaying availability summary: " + e.getMessage());
        }
    }

    public void displayAvailabilityByType() {
        String sql = "SELECT s.slot_type, "
                + "SUM(CASE WHEN s.slot_status = 'Available' THEN 1 ELSE 0 END) AS available_count, "
                + "SUM(CASE WHEN s.slot_status = 'Occupied' THEN 1 ELSE 0 END) AS occupied_count, "
                + "SUM(CASE WHEN s.slot_status = 'Blocked' THEN 1 ELSE 0 END) AS blocked_count, "
                + "COUNT(*) AS total_count "
                + "FROM parking_slot s "
                + "GROUP BY s.slot_type "
                + "ORDER BY s.slot_type";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("================ AVAILABILITY BY VEHICLE TYPE ================");
            System.out.printf("%-16s | %-10s | %-10s | %-10s | %-10s%n",
                    "Slot / Type", "Total", "Available", "Occupied", "Blocked");
            System.out.println("--------------------------------------------------------------");
            boolean found = false;
            while (rs.next()) {
                found = true;
                System.out.printf("%-16s | %-10d | %-10d | %-10d | %-10d%n",
                        rs.getString("slot_type"),
                        rs.getInt("total_count"),
                        rs.getInt("available_count"),
                        rs.getInt("occupied_count"),
                        rs.getInt("blocked_count"));
            }
            if (!found) {
                System.out.println("No slots registered yet.");
            }
            System.out.println("==============================================================");
        } catch (SQLException e) {
            System.err.println("Error displaying availability by type: " + e.getMessage());
        }
    }

    public void searchAvailableSlotsByLocation(String location) {
        String sql = "SELECT s.slot_id, l.lot_id, l.lot_name, l.location, s.slot_number, s.slot_type "
                + "FROM parking_slot s "
                + "JOIN parking_lot l ON s.lot_id = l.lot_id "
                + "WHERE s.slot_status = 'Available' AND l.location LIKE ? "
                + "ORDER BY l.location, s.slot_number";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + location + "%");
            try (ResultSet rs = ps.executeQuery()) {
                System.out.printf("%-8s | %-20s | %-16s | %-10s | %-14s%n",
                        "Slot ID", "Parking Lot", "Location", "Slot No", "Vehicle Type");
                System.out.println("-----------------------------------------------------------------------------");
                boolean found = false;
                while (rs.next()) {
                    found = true;
                    System.out.printf("%-8d | %-20s | %-16s | %-10s | %-14s%n",
                            rs.getInt("slot_id"),
                            rs.getString("lot_name"),
                            rs.getString("location"),
                            rs.getString("slot_number"),
                            rs.getString("slot_type"));
                }
                if (!found) {
                    System.out.println("No available slots found for location matching '" + location + "'.");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error searching available slots by location: " + e.getMessage());
        }
    }

    private void printSlotRows(ResultSet rs) throws SQLException {
        System.out.printf("%-8s | %-20s | %-10s | %-14s | %-10s%n",
                "Slot ID", "Parking Lot", "Slot No", "Type", "Status");
        System.out.println("-------------------------------------------------------------------------");
        boolean found = false;
        while (rs.next()) {
            found = true;
            System.out.printf("%-8d | %-20s | %-10s | %-14s | %-10s%n",
                    rs.getInt("slot_id"),
                    rs.getString("lot_name"),
                    rs.getString("slot_number"),
                    rs.getString("slot_type"),
                    rs.getString("slot_status"));
        }
        if (!found) {
            System.out.println("No parking slots found.");
        }
    }
}
