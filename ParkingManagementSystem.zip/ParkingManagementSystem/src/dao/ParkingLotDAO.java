package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.ParkingLot;
import util.DBConnection;

// DAO for managing parking lot records and overall facility operations
public class ParkingLotDAO {

    public boolean addParkingLot(ParkingLot lot) {
        String sql = "INSERT INTO parking_lot (lot_name, location, address, total_capacity, opening_time, closing_time, status) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, lot.getName());
            ps.setString(2, lot.getLocation());
            ps.setString(3, lot.getAddress());
            ps.setInt(4, lot.getTotalCapacity());
            ps.setString(5, lot.getOpeningTime());
            ps.setString(6, lot.getClosingTime());
            ps.setString(7, lot.getStatus());
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error adding parking lot: " + e.getMessage());
            return false;
        }
    }

    public void viewAllLots() {
        String sql = "SELECT * FROM parking_lot ORDER BY lot_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            printLots(rs);
        } catch (SQLException e) {
            System.err.println("Error viewing parking lots: " + e.getMessage());
        }
    }

    public ParkingLot getLotById(int lotId) {
        String sql = "SELECT * FROM parking_lot WHERE lot_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, lotId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching parking lot: " + e.getMessage());
        }
        return null;
    }

    public void searchById(int lotId) {
        String sql = "SELECT * FROM parking_lot WHERE lot_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, lotId);
            try (ResultSet rs = ps.executeQuery()) {
                printLots(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error searching parking lot: " + e.getMessage());
        }
    }

    public void searchByLocation(String location) {
        String sql = "SELECT * FROM parking_lot WHERE location LIKE ? ORDER BY lot_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + location + "%");
            try (ResultSet rs = ps.executeQuery()) {
                printLots(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error searching parking lot by location: " + e.getMessage());
        }
    }

    public boolean updateLot(ParkingLot lot) {
        String sql = "UPDATE parking_lot SET lot_name = ?, location = ?, address = ?, total_capacity = ?, "
                + "opening_time = ?, closing_time = ?, status = ? WHERE lot_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, lot.getName());
            ps.setString(2, lot.getLocation());
            ps.setString(3, lot.getAddress());
            ps.setInt(4, lot.getTotalCapacity());
            ps.setString(5, lot.getOpeningTime());
            ps.setString(6, lot.getClosingTime());
            ps.setString(7, lot.getStatus());
            ps.setInt(8, lot.getLotId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating parking lot: " + e.getMessage());
            return false;
        }
    }

    public boolean setLotStatus(int lotId, String status) {
        String sql = "UPDATE parking_lot SET status = ? WHERE lot_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, lotId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error setting lot status: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteLot(int lotId) {
        try (Connection con = DBConnection.getConnection()) {
            // Check for dependent slots
            try (PreparedStatement psSlot = con.prepareStatement("SELECT COUNT(*) FROM parking_slot WHERE lot_id = ?")) {
                psSlot.setInt(1, lotId);
                try (ResultSet rs = psSlot.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        System.out.println("Cannot delete: This parking lot has " + rs.getInt(1) + " dependent parking slot(s). Delete slots first or deactivate the lot.");
                        return false;
                    }
                }
            }

            // Check for active or historical records
            try (PreparedStatement psRec = con.prepareStatement("SELECT COUNT(*) FROM parking_record WHERE lot_id = ?")) {
                psRec.setInt(1, lotId);
                try (ResultSet rs = psRec.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        System.out.println("Cannot delete: This parking lot has " + rs.getInt(1) + " historical/active parking record(s). Cannot delete lot with dependent records.");
                        return false;
                    }
                }
            }

            // Safe to delete
            try (PreparedStatement psDel = con.prepareStatement("DELETE FROM parking_lot WHERE lot_id = ?")) {
                psDel.setInt(1, lotId);
                return psDel.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            System.err.println("Error deleting parking lot: " + e.getMessage());
            return false;
        }
    }

    public List<ParkingLot> getAllActiveLots() {
        List<ParkingLot> list = new ArrayList<>();
        String sql = "SELECT * FROM parking_lot WHERE status = 'Active' ORDER BY lot_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching active lots: " + e.getMessage());
        }
        return list;
    }

    public int getTotalLotsCount() {
        String sql = "SELECT COUNT(*) FROM parking_lot";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("Error counting lots: " + e.getMessage());
        }
        return 0;
    }

    private ParkingLot mapRow(ResultSet rs) throws SQLException {
        return new ParkingLot(
                rs.getInt("lot_id"),
                rs.getString("lot_name"),
                rs.getString("location"),
                rs.getString("address"),
                rs.getInt("total_capacity"),
                rs.getString("opening_time"),
                rs.getString("closing_time"),
                rs.getString("status")
        );
    }

    private void printLots(ResultSet rs) throws SQLException {
        System.out.printf("%-6s | %-22s | %-16s | %-8s | %-10s | %-10s | %-10s%n",
                "Lot ID", "Name", "Location", "Capacity", "Open", "Close", "Status");
        System.out.println("--------------------------------------------------------------------------------------------------");
        boolean found = false;
        while (rs.next()) {
            found = true;
            System.out.printf("%-6d | %-22s | %-16s | %-8d | %-10s | %-10s | %-10s%n",
                    rs.getInt("lot_id"),
                    rs.getString("lot_name"),
                    rs.getString("location"),
                    rs.getInt("total_capacity"),
                    rs.getString("opening_time"),
                    rs.getString("closing_time"),
                    rs.getString("status"));
        }
        if (!found) {
            System.out.println("No parking lots found.");
        }
    }
}
