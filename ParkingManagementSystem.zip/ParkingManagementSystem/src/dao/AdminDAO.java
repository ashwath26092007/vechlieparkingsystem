package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import util.DBConnection;

// DAO for admin authentication and credential management
public class AdminDAO {

    public boolean login(String username, String password) {
        String sql = "SELECT * FROM admin WHERE username = ? AND password = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            System.err.println("Database error during login: " + e.getMessage());
            return false;
        }
    }

    public boolean changePassword(String username, String oldPassword, String newPassword) {
        if (!login(username, oldPassword)) {
            System.out.println("Incorrect current password.");
            return false;
        }
        String sql = "UPDATE admin SET password = ? WHERE username = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, newPassword);
            ps.setString(2, username);
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Database error updating password: " + e.getMessage());
            return false;
        }
    }
}
