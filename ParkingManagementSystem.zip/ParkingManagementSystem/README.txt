================================================================================
PARKING MANAGEMENT SYSTEM (Core Java + JDBC + MySQL, Console-Based Application)
================================================================================

1. PROJECT OVERVIEW
-------------------
The Parking Management System is a clean, modular, and beginner-friendly Java 
console application designed for managing multi-lot parking facilities, parking slots, 
vehicle registrations, real-time vehicle entry/exit tracking, automated parking fee 
calculations, payment auditing, and capacity analytics.

Built without external heavy frameworks (no Spring Boot, Hibernate, or Maven), 
it relies purely on Core Java (JDK 17+), standard JDBC DriverManager/PreparedStatement, 
and MySQL. It is ideally suited for academic project submissions and viva demonstrations.


2. TECHNOLOGIES USED
--------------------
* Core Java: JDK 17 or higher
* Database: MySQL Server (8.0+)
* Database Connectivity: JDBC (Java Database Connectivity)
* Driver: MySQL Connector/J 8.0.33 (located in the lib/ folder)
* Input Handling: Java Scanner with input sanitization and exception shielding


3. FOLDER STRUCTURE
-------------------
ParkingManagementSystem/
|-- src/
|   |-- app/
|   |   `-- Main.java             (Console UI, menus, input flow, controllers)
|   |-- model/
|   |   |-- Admin.java            (Administrator POJO)
|   |   |-- ParkingLot.java       (Parking facility POJO)
|   |   |-- ParkingSlot.java      (Parking slot POJO)
|   |   |-- Vehicle.java          (Vehicle registration POJO)
|   |   |-- ParkingRecord.java    (Active and historical parking session POJO)
|   |   `-- Payment.java          (Payment receipt and ledger POJO)
|   |-- dao/
|   |   |-- AdminDAO.java         (Admin authentication)
|   |   |-- ParkingLotDAO.java    (Lot CRUD, capacity lookups, location search)
|   |   |-- ParkingSlotDAO.java   (Slot CRUD, auto-generation, block/unblock)
|   |   |-- VehicleDAO.java       (Vehicle registration, type & owner search)
|   |   |-- ParkingRecordDAO.java (Atomic entry/exit transactions & reporting)
|   |   `-- PaymentDAO.java       (Payment processing, audit & revenue calculations)
|   `-- util/
|       |-- DBConnection.java     (Connection manager with multi-stage fallback)
|       |-- DatabaseSetup.java    (Automatic schema creation & demo data seeder)
|       `-- FeeCalculator.java    (Configurable hourly rates & pricing engine)
|-- lib/
|   `-- mysql-connector-j-8.0.33.jar (MySQL JDBC driver)
|-- database.sql                  (Full SQL script for MySQL Workbench import)
|-- db.properties                 (MySQL credentials configuration file)
|-- README.txt                    (Complete documentation and user guide)
`-- run.bat                       (Automated Windows build and run batch file)


4. REQUIREMENTS
---------------
* Windows 10/11
* Java Development Kit (JDK 17 or higher installed, javac available in PATH)
* MySQL Server (8.0 or higher running on localhost:3306)


5. DEFAULT DEMONSTRATION CREDENTIALS
------------------------------------
* Username: admin
* Password: admin123

Note: These credentials are provided for evaluation and demonstration purposes.
The admin table in MySQL stores these credentials. Attempting incorrect credentials 
more than 3 times will lock the session and terminate the application.


6. HOW TO RUN
-------------
Method A (Recommended - Automated Batch Script):
  1. Ensure your MySQL server service is running.
  2. Double-click "run.bat" in the project root directory.
  3. The script automatically:
     - Verifies javac compiler in your PATH.
     - Ensures mysql-connector-j-8.0.33.jar is present in lib/.
     - Compiles all packages (app, model, dao, util) into the out/ folder.
     - Initializes the database automatically if needed.
     - Launches the application.

Method B (Manual Command Prompt):
  1. Open Command Prompt and navigate to the project directory:
     cd C:\Users\dhara\Downloads\ParkingManagementSystem
  2. Compile the source code:
     javac -d out -cp "lib\*" src\app\*.java src\model\*.java src\dao\*.java src\util\*.java
  3. Execute the program:
     java -cp "out;lib\*" app.Main


7. DATABASE SETUP & CONFIGURATION
---------------------------------
Option 1: Fully Automatic (Zero SQL Setup Needed)
  The application automatically connects to MySQL upon launch, creates the database 
  `parking_management_db` if it does not already exist, creates all 6 tables, and inserts 
  initial sample lots, slots, and vehicles.
  It is completely idempotent: restarting the application will never delete your data 
  or insert duplicate demo records.

Option 2: Import via MySQL Workbench
  1. Open MySQL Workbench and connect to your local MySQL instance.
  2. Go to File -> Open SQL Script...
  3. Select `database.sql` from the project root folder.
  4. Click the lightning bolt icon (Execute).
  5. The entire database, schema constraints, and sample data will be created.

Configuring Credentials (db.properties):
  To change your MySQL username or password, edit `db.properties` in the project root:
    db.host=localhost
    db.port=3306
    db.user=root
    db.password=1234


8. PARKING FEE CALCULATION RULES
--------------------------------
The system uses an hourly pricing model configured in `util.FeeCalculator`:

Vehicle Type   | First Hour Rate | Additional Hour Rate (or part thereof)
------------------------------------------------------------------------
Two-wheeler    | Rs. 20.00       | Rs. 10.00
Four-wheeler   | Rs. 40.00       | Rs. 20.00
Heavy vehicle  | Rs. 100.00      | Rs. 50.00

Pricing Rules:
* Any partial hour is rounded UP to the next full billable hour.
* A minimum of 1 hour is billed for any short stay (< 60 minutes).
* Example: A Two-wheeler parked for 2 hours and 15 minutes is billed for 3 hours:
  Hour 1: Rs. 20
  Hour 2: Rs. 10
  Hour 3: Rs. 10
  Total: Rs. 40.00
* Example: A Four-wheeler parked for 1 hour and 10 minutes is billed for 2 hours:
  Hour 1: Rs. 40
  Hour 2: Rs. 20
  Total: Rs. 60.00


9. MAJOR WORKFLOWS & HOW TO USE
-------------------------------

A. Manage Parking Lots (Menu Option 1)
   - Add new parking facilities with name, location, address, and capacity.
   - Search lots by ID or location keyword (e.g., "Downtown").
   - Update lot details or toggle status between Active and Inactive.
   - Deleting a parking lot is protected: lots with associated parking slots or 
     records cannot be deleted to maintain referential integrity.

B. Manage Parking Slots (Menu Option 2)
   - Add individual slots manually (e.g. S001, B01) with vehicle type compatibility.
   - Auto-generate batches of slots (e.g. 10 Four-wheeler slots starting with prefix 'S').
     The generator verifies existing slot numbers to prevent duplicate slot numbers.
   - Change slot status: Administrators can block slots (for maintenance/cleaning) 
     or unblock available slots. Occupied slots cannot be blocked or deleted.

C. Vehicle Registration (Menu Option 3)
   - Register vehicles with plate number, vehicle type, owner name, and phone.
   - Registration numbers are strictly unique and normalized to uppercase.
   - Search vehicles by owner, type, or registration number, and view parking history.

D. Vehicle Entry (Menu Option 4)
   - Step 1: Admin enters vehicle registration number.
   - Step 2: System checks if vehicle is registered. If not, offers on-the-spot registration.
   - Step 3: Verifies vehicle does not already have an active parking session.
   - Step 4: Displays active parking lots and available slots matching the vehicle type.
   - Step 5: Admin selects a slot.
   - Step 6: In a single atomic JDBC transaction, the parking record is created and the 
     selected slot status is marked as 'Occupied'.
   - Step 7: A parking entry confirmation receipt is displayed.

E. Vehicle Exit (Menu Option 5)
   - Step 1: Admin enters registration number or record ID.
   - Step 2: Locates active parking session.
   - Step 3: Automatically calculates elapsed duration using Java Date-Time APIs.
   - Step 4: Calculates parking fee according to vehicle type and rounded-up hours.
   - Step 5: Displays summary and prompts for confirmation.
   - Step 6: In an atomic JDBC transaction, the record is marked as 'Completed' with the 
     final fee and exit timestamp, and the slot is released to 'Available'.
   - Step 7: Prompts admin to record payment immediately or defer.

F. Manage Payments (Menu Option 7)
   - Record payment with method (Cash, UPI, Card, Bank Transfer).
   - Generates transaction reference ID.
   - Prevents duplicate successful payments for the same parking session.
   - Supports marking payments as Successful, Failed, or Pending.
   - Search payment transactions and view unpaid outstanding parking sessions.

G. Quick Vehicle Search (Menu Option 8)
   - Instant 360-degree vehicle profile: displays owner info, vehicle specs, 
     current live parking status (lot name, slot, entry time if parked), and history.

H. Reports and Statistics (Menu Option 9)
   - Live analytics generated directly from SQL queries:
     1. All registered vehicles
     2. Currently parked vehicles count and list
     3. Completed sessions
     4. Vehicle parking history
     5. Records for a specific date or date range
     6. Total lots & slots
     7. Available vs Occupied vs Blocked slots
     8. Vehicles count by type
     9. Total parking fees generated vs actual collected revenue
     10. Outstanding pending payments
     11. Top 5 most frequently used parking lots
     12. Average parking duration

I. Parking Availability Dashboard (Menu Option 10)
   - Real-time availability breakdown across each lot and overall system:
     Lot Name | Total Capacity | Available | Occupied | Blocked | Availability %
   - Filter available slots by vehicle type or facility location.


10. DATABASE RELATIONSHIPS & CONSTRAINTS
----------------------------------------
* parking_lot (1) -> (N) parking_slot (FOREIGN KEY lot_id)
* parking_slot: UNIQUE KEY (lot_id, slot_number) prevents duplicate slots in a lot.
* vehicle: UNIQUE KEY (reg_number) prevents duplicate vehicle registration.
* parking_record: References vehicle(vehicle_id), parking_lot(lot_id), and parking_slot(slot_id).
* payment: References parking_record(record_id).
* Transactions: All multi-step allocations (entry check + slot occupy, exit check + slot release) 
  use JDBC connection.setAutoCommit(false) with commit() and rollback() to guarantee data integrity.


11. TROUBLESHOOTING & COMMON ISSUES
-----------------------------------
Q: "Communications link failure / Connection refused"
A: MySQL service is not running. 
   On Windows: Press Win+R, type `services.msc`, locate "MySQL" or "MYSQL267", and click Start.

Q: "Access denied for user 'root'@'localhost'"
A: MySQL password in `db.properties` is incorrect. Open `db.properties` and update `db.password` 
   with your MySQL root password.

Q: "javac is not recognized as an internal or external command"
A: Java JDK is not added to your system PATH. 
   Install JDK 17+ and add `C:\Program Files\Java\jdk-XX\bin` to your System Environment PATH.

Q: "MySQL driver jar missing"
A: `mysql-connector-j-8.0.33.jar` is included in the `lib` folder. If deleted, `run.bat` will 
   automatically re-download it from Maven Central.
================================================================================
