@echo off
setlocal
cd /d "%~dp0"
title Parking Management System

set JAR=lib\mysql-connector-j-8.0.33.jar

echo ==================================================
echo         PARKING MANAGEMENT SYSTEM BUILD & RUN      
echo ==================================================

where javac >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Java JDK compiler (javac) was not found in your PATH.
    echo Please install JDK 17 or higher and add its bin folder to PATH.
    pause
    exit /b 1
)

if not exist lib mkdir lib
if not exist %JAR% (
    echo [INFO] MySQL Connector/J driver not found in lib. Downloading...
    powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.0.33/mysql-connector-j-8.0.33.jar' -OutFile '%JAR%'"
    if not exist %JAR% (
        echo.
        echo [ERROR] Automatic download failed.
        echo Please download mysql-connector-j-8.0.33.jar manually and place it into the 'lib' folder.
        pause
        exit /b 1
    )
)

echo [INFO] Compiling Java source files...
if not exist out mkdir out
javac -d out -cp "lib\*" src\app\*.java src\model\*.java src\dao\*.java src\util\*.java
if errorlevel 1 (
    echo.
    echo [ERROR] Compilation failed. Please check the errors above.
    pause
    exit /b 1
)

echo [INFO] Compilation successful!
echo.

if exist db.properties (
    echo Found saved db.properties configuration. Launching system...
    java -cp "out;lib\*" app.Main
) else (
    set /p DBUSER=MySQL username [press Enter for root]: 
    if "%DBUSER%"=="" set DBUSER=root
    set /p DBPASS=MySQL password: 
    echo.
    java -Ddb.user=%DBUSER% "-Ddb.password=%DBPASS%" -cp "out;lib\*" app.Main
)

echo.
pause
