-- =========================================================================
-- PARKING MANAGEMENT SYSTEM DATABASE SCRIPT
-- Database Name: parking_management_db
-- Run this entire script in MySQL Workbench or MySQL Command Line Client.
-- =========================================================================

CREATE DATABASE IF NOT EXISTS parking_management_db;
USE parking_management_db;

-- 1. Table: admin (Administrator credentials)
CREATE TABLE IF NOT EXISTS admin (
    username VARCHAR(30) PRIMARY KEY,
    password VARCHAR(30) NOT NULL
);

-- 2. Table: parking_lot (Parking facilities/locations)
CREATE TABLE IF NOT EXISTS parking_lot (
    lot_id         INT AUTO_INCREMENT PRIMARY KEY,
    lot_name       VARCHAR(60) NOT NULL,
    location       VARCHAR(60) NOT NULL,
    address        VARCHAR(150),
    total_capacity INT NOT NULL,
    opening_time   VARCHAR(10) NOT NULL DEFAULT '06:00 AM',
    closing_time   VARCHAR(10) NOT NULL DEFAULT '11:00 PM',
    status         VARCHAR(15) NOT NULL DEFAULT 'Active'
);

-- 3. Table: parking_slot (Individual slots inside a parking lot)
CREATE TABLE IF NOT EXISTS parking_slot (
    slot_id     INT AUTO_INCREMENT PRIMARY KEY,
    lot_id      INT NOT NULL,
    slot_number VARCHAR(20) NOT NULL,
    slot_type   VARCHAR(20) NOT NULL, -- 'Two-wheeler', 'Four-wheeler', 'Heavy vehicle'
    slot_status VARCHAR(15) NOT NULL DEFAULT 'Available', -- 'Available', 'Occupied', 'Blocked'
    CONSTRAINT fk_slot_lot FOREIGN KEY (lot_id) REFERENCES parking_lot(lot_id) ON DELETE RESTRICT,
    CONSTRAINT uk_lot_slot UNIQUE (lot_id, slot_number)
);

-- 4. Table: vehicle (Registered vehicles)
CREATE TABLE IF NOT EXISTS vehicle (
    vehicle_id        INT AUTO_INCREMENT PRIMARY KEY,
    reg_number        VARCHAR(20) NOT NULL UNIQUE,
    vehicle_type      VARCHAR(20) NOT NULL, -- 'Two-wheeler', 'Four-wheeler', 'Heavy vehicle'
    owner_name        VARCHAR(60) NOT NULL,
    owner_phone       VARCHAR(15) NOT NULL,
    vehicle_model     VARCHAR(50),
    registration_date DATETIME NOT NULL
);

-- 5. Table: parking_record (Active and historical parking sessions)
CREATE TABLE IF NOT EXISTS parking_record (
    record_id      INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id     INT NOT NULL,
    lot_id         INT NOT NULL,
    slot_id        INT NOT NULL,
    entry_time     DATETIME NOT NULL,
    exit_time      DATETIME NULL,
    duration_hours INT DEFAULT 0,
    fee            DOUBLE NOT NULL DEFAULT 0.0,
    parking_status VARCHAR(15) NOT NULL DEFAULT 'Active', -- 'Active', 'Completed', 'Cancelled'
    CONSTRAINT fk_record_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicle(vehicle_id) ON DELETE RESTRICT,
    CONSTRAINT fk_record_lot     FOREIGN KEY (lot_id) REFERENCES parking_lot(lot_id) ON DELETE RESTRICT,
    CONSTRAINT fk_record_slot    FOREIGN KEY (slot_id) REFERENCES parking_slot(slot_id) ON DELETE RESTRICT
);

-- 6. Table: payment (Payment transactions for parking sessions)
CREATE TABLE IF NOT EXISTS payment (
    payment_id      INT AUTO_INCREMENT PRIMARY KEY,
    record_id       INT NOT NULL,
    amount          DOUBLE NOT NULL,
    payment_time    DATETIME NOT NULL,
    payment_method  VARCHAR(20) NOT NULL, -- 'Cash', 'UPI', 'Card', 'Bank Transfer'
    payment_status  VARCHAR(15) NOT NULL DEFAULT 'Pending', -- 'Pending', 'Successful', 'Failed', 'Refunded'
    transaction_ref VARCHAR(50),
    CONSTRAINT fk_payment_record FOREIGN KEY (record_id) REFERENCES parking_record(record_id) ON DELETE RESTRICT
);

-- =========================================================================
-- INITIAL DEMONSTRATION DATA (FOR TESTING & COLLEGE VIVA PRESENTATIONS)
-- =========================================================================

-- Default Administrator (Username: admin | Password: admin123)
INSERT INTO admin (username, password)
VALUES ('admin', 'admin123')
ON DUPLICATE KEY UPDATE username = username;

-- Sample Parking Lots
INSERT INTO parking_lot (lot_id, lot_name, location, address, total_capacity, opening_time, closing_time, status)
VALUES
(1, 'Central City Plaza', 'Downtown', '101 MG Road, Downtown', 50, '06:00 AM', '11:00 PM', 'Active'),
(2, 'Metro Express Hub',  'North Station', 'Station Road, North Sector', 40, '05:00 AM', '11:30 PM', 'Active'),
(3, 'Tech Corridor Hub',  'Electronic City', 'Phase 1 Expressway', 60, '24 Hours', '24 Hours', 'Active')
ON DUPLICATE KEY UPDATE lot_id = lot_id;

-- Sample Parking Slots
INSERT INTO parking_slot (slot_id, lot_id, slot_number, slot_type, slot_status)
VALUES
-- Lot 1: Central City Plaza
(1, 1, 'S001', 'Two-wheeler', 'Available'),
(2, 1, 'S002', 'Two-wheeler', 'Available'),
(3, 1, 'S003', 'Four-wheeler', 'Available'),
(4, 1, 'S004', 'Four-wheeler', 'Available'),
(5, 1, 'S005', 'Heavy vehicle', 'Available'),
-- Lot 2: Metro Express Hub
(6, 2, 'M001', 'Two-wheeler', 'Available'),
(7, 2, 'M002', 'Four-wheeler', 'Available'),
(8, 2, 'M003', 'Four-wheeler', 'Available'),
(9, 2, 'M004', 'Heavy vehicle', 'Available'),
-- Lot 3: Tech Corridor Hub
(10, 3, 'T001', 'Two-wheeler', 'Available'),
(11, 3, 'T002', 'Four-wheeler', 'Available'),
(12, 3, 'T003', 'Heavy vehicle', 'Available')
ON DUPLICATE KEY UPDATE slot_id = slot_id;

-- Sample Vehicles
INSERT INTO vehicle (vehicle_id, reg_number, vehicle_type, owner_name, owner_phone, vehicle_model, registration_date)
VALUES
(1, 'KA01AB1234', 'Four-wheeler', 'Rahul Sharma', '9876543210', 'Hyundai Creta', NOW()),
(2, 'TN07CD5678', 'Two-wheeler',  'Sneha Patel',  '9123456780', 'Honda Activa',  NOW()),
(3, 'DL03EF9012', 'Heavy vehicle', 'Rajesh Singh', '9988776655', 'Tata 407',      NOW())
ON DUPLICATE KEY UPDATE vehicle_id = vehicle_id;

-- Sample Historical Parking Record & Payment for immediate reports demonstration
INSERT INTO parking_record (record_id, vehicle_id, lot_id, slot_id, entry_time, exit_time, duration_hours, fee, parking_status)
VALUES
(1, 2, 1, 1, DATE_SUB(NOW(), INTERVAL 3 HOUR), DATE_SUB(NOW(), INTERVAL 1 HOUR), 2, 30.0, 'Completed')
ON DUPLICATE KEY UPDATE record_id = record_id;

INSERT INTO payment (payment_id, record_id, amount, payment_time, payment_method, payment_status, transaction_ref)
VALUES
(1, 1, 30.0, DATE_SUB(NOW(), INTERVAL 1 HOUR), 'UPI', 'Successful', 'UPI-DEMO-98231')
ON DUPLICATE KEY UPDATE payment_id = payment_id;
